"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"
import { ArrowRight, Anchor, TrendingUp, Shield, Zap } from "lucide-react"

export default function Home() {
  const [activeTab, setActiveTab] = useState("features")

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-muted/20">
      <Navbar />

      {/* Hero Section */}
      <section className="relative overflow-hidden pt-20 pb-32 lg:pt-40 lg:pb-48 px-4 md:px-6">
        {/* Background gradient effects */}
        <div className="absolute inset-0 -z-10">
          <div className="absolute top-0 left-1/4 w-96 h-96 bg-accent/10 rounded-full blur-3xl"></div>
          <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-secondary/10 rounded-full blur-3xl"></div>
        </div>

        <div className="max-w-7xl mx-auto">
          <div className="text-center space-y-8">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full border border-accent/30 bg-accent/5">
              <span className="text-accent text-sm font-semibold">Revolusi Logistik Laut</span>
            </div>

            <h1 className="text-5xl md:text-7xl font-bold text-balance leading-tight">
              <span className="text-foreground">Kelola Pengiriman </span>
              <span className="bg-gradient-to-r from-accent to-secondary bg-clip-text text-transparent">
                dengan Presisi
              </span>
            </h1>

            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Portal terintegrasi satu pintu untuk manajemen ekspor-impor barang. Pantau, rencanakan, dan optimalkan
              setiap pengiriman Anda secara real-time.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center pt-8">
              <Link href="/auth/login">
                <Button size="lg" className="gap-2">
                  Mulai Sekarang <ArrowRight className="w-4 h-4" />
                </Button>
              </Link>
              <Button size="lg" variant="outline">
                Pelajari Lebih Lanjut
              </Button>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-3 gap-4 md:gap-8 pt-16 border-t border-border">
              <div className="space-y-2">
                <p className="text-3xl font-bold text-accent">500+</p>
                <p className="text-sm text-muted-foreground">Pengiriman Bulanan</p>
              </div>
              <div className="space-y-2">
                <p className="text-3xl font-bold text-secondary">99.8%</p>
                <p className="text-sm text-muted-foreground">Akurasi Tracking</p>
              </div>
              <div className="space-y-2">
                <p className="text-3xl font-bold text-accent">24/7</p>
                <p className="text-sm text-muted-foreground">Dukungan Pelanggan</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 px-4 md:px-6 bg-card/50">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16 space-y-4">
            <h2 className="text-4xl md:text-5xl font-bold text-balance">Fitur Unggulan</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Solusi lengkap untuk semua kebutuhan logistik laut Anda
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card className="border-border/50 hover:border-accent/50 transition-colors">
              <CardHeader>
                <div className="w-12 h-12 rounded-lg bg-accent/10 flex items-center justify-center mb-4">
                  <Anchor className="w-6 h-6 text-accent" />
                </div>
                <CardTitle>Ekspor Barang</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Kelola seluruh proses ekspor dari pemesanan hingga penagihan
                </p>
              </CardContent>
            </Card>

            <Card className="border-border/50 hover:border-secondary/50 transition-colors">
              <CardHeader>
                <div className="w-12 h-12 rounded-lg bg-secondary/10 flex items-center justify-center mb-4">
                  <TrendingUp className="w-6 h-6 text-secondary" />
                </div>
                <CardTitle>Impor Barang</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Pantau kedatangan kapal dan atur penjadwalan bongkar muat
                </p>
              </CardContent>
            </Card>

            <Card className="border-border/50 hover:border-accent/50 transition-colors">
              <CardHeader>
                <div className="w-12 h-12 rounded-lg bg-accent/10 flex items-center justify-center mb-4">
                  <Zap className="w-6 h-6 text-accent" />
                </div>
                <CardTitle>Tracking Real-time</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">Monitor posisi kapal dan status pengiriman setiap saat</p>
              </CardContent>
            </Card>

            <Card className="border-border/50 hover:border-secondary/50 transition-colors">
              <CardHeader>
                <div className="w-12 h-12 rounded-lg bg-secondary/10 flex items-center justify-center mb-4">
                  <Shield className="w-6 h-6 text-secondary" />
                </div>
                <CardTitle>Pembayaran Aman</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">Sistem pembayaran terkonsolidasi dan laporan otomatis</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Process Section */}
      <section className="py-20 px-4 md:px-6">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16 space-y-4">
            <h2 className="text-4xl md:text-5xl font-bold text-balance">Alur Kerja Sederhana</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Tiga tahap mudah untuk setiap transaksi logistik
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <div className="space-y-4">
              <div className="w-16 h-16 rounded-full bg-gradient-to-br from-accent to-primary flex items-center justify-center text-white font-bold text-xl">
                1
              </div>
              <h3 className="text-2xl font-bold">Pra-Layanan</h3>
              <p className="text-muted-foreground">
                Pemesanan, validasi dokumen, dan perencanaan jadwal kapal yang optimal
              </p>
            </div>

            <div className="space-y-4">
              <div className="w-16 h-16 rounded-full bg-gradient-to-br from-secondary to-accent flex items-center justify-center text-white font-bold text-xl">
                2
              </div>
              <h3 className="text-2xl font-bold">Layanan</h3>
              <p className="text-muted-foreground">
                Monitoring real-time, kontrol operasional, dan notifikasi proaktif
              </p>
            </div>

            <div className="space-y-4">
              <div className="w-16 h-16 rounded-full bg-gradient-to-br from-primary to-secondary flex items-center justify-center text-white font-bold text-xl">
                3
              </div>
              <h3 className="text-2xl font-bold">Pasca-Layanan</h3>
              <p className="text-muted-foreground">Penagihan terkonsolidasi, pelaporan, dan evaluasi kinerja</p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 md:px-6 bg-gradient-to-r from-primary to-primary/80">
        <div className="max-w-4xl mx-auto text-center space-y-8 text-white">
          <h2 className="text-4xl md:text-5xl font-bold text-balance">Siap Mengoptimalkan Logistik Anda?</h2>
          <p className="text-xl opacity-90">
            Bergabunglah dengan ratusan perusahaan logistik yang telah mempercayai ShipSmart
          </p>
          <Link href="/auth/signup">
            <Button size="lg" variant="secondary" className="gap-2">
              Daftar Gratis <ArrowRight className="w-4 h-4" />
            </Button>
          </Link>
        </div>
      </section>

      <Footer />
    </div>
  )
}
