"use client"
import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Check } from "lucide-react"

export default function PricingPage() {
  const plans = [
    {
      name: "Starter",
      price: "Rp 5.000.000",
      period: "/bulan",
      description: "Untuk UKM dengan volume pengiriman rendah",
      features: [
        "Hingga 50 pengiriman/bulan",
        "Tracking real-time dasar",
        "Laporan bulanan",
        "Email support",
        "Dashboard sederhana",
      ],
      cta: "Mulai",
    },
    {
      name: "Professional",
      price: "Rp 15.000.000",
      period: "/bulan",
      description: "Untuk perusahaan menengah dengan volume tinggi",
      features: [
        "Hingga 500 pengiriman/bulan",
        "Tracking real-time premium",
        "Laporan analytics mendalam",
        "Priority support 24/7",
        "Dashboard advanced",
        "API integration",
        "Multi-user access",
      ],
      cta: "Pilih Plan",
      popular: true,
    },
    {
      name: "Enterprise",
      price: "Custom",
      period: "",
      description: "Untuk korporasi besar dengan kebutuhan khusus",
      features: [
        "Unlimited pengiriman",
        "Tracking enterprise-grade",
        "Custom reporting",
        "Dedicated support team",
        "Dashboard kustom",
        "Full API access",
        "Unlimited users",
        "SLA guarantee 99.9%",
      ],
      cta: "Hubungi Sales",
    },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-muted/20">
      <Navbar />

      {/* Header */}
      <section className="pt-20 pb-12 px-4 md:px-6">
        <div className="max-w-7xl mx-auto text-center space-y-4">
          <h1 className="text-5xl md:text-6xl font-bold text-balance">Harga Transparan & Terjangkau</h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Pilih paket yang sesuai dengan kebutuhan bisnis Anda
          </p>
        </div>
      </section>

      {/* Pricing Cards */}
      <section className="py-20 px-4 md:px-6">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-3 gap-8">
            {plans.map((plan, idx) => (
              <Card
                key={idx}
                className={`border-border/50 ${plan.popular ? "ring-2 ring-accent border-accent/50" : ""} transition-all hover:shadow-lg`}
              >
                {plan.popular && (
                  <div className="bg-accent text-white px-4 py-2 text-center text-sm font-semibold">PALING POPULER</div>
                )}
                <CardHeader>
                  <CardTitle className="text-2xl">{plan.name}</CardTitle>
                  <CardDescription>{plan.description}</CardDescription>
                  <div className="mt-6 space-y-1">
                    <div className="text-4xl font-bold text-foreground">{plan.price}</div>
                    <div className="text-sm text-muted-foreground">{plan.period}</div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-6">
                  <Button className="w-full" variant={plan.popular ? "default" : "outline"}>
                    {plan.cta}
                  </Button>

                  <ul className="space-y-3">
                    {plan.features.map((feature, featureIdx) => (
                      <li key={featureIdx} className="flex items-center gap-3 text-sm">
                        <Check className="w-5 h-5 text-green-600 flex-shrink-0" />
                        {feature}
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-20 px-4 md:px-6 bg-card/50">
        <div className="max-w-4xl mx-auto space-y-8">
          <div className="text-center space-y-2 mb-12">
            <h2 className="text-3xl font-bold">Pertanyaan Umum</h2>
            <p className="text-muted-foreground">Informasi tentang paket dan penawaran kami</p>
          </div>

          <div className="grid gap-6">
            {[
              {
                q: "Apakah ada biaya setup?",
                a: "Tidak ada biaya setup atau biaya tersembunyi. Anda hanya membayar paket yang dipilih.",
              },
              {
                q: "Bisakah saya mengubah paket?",
                a: "Ya, Anda bisa upgrade atau downgrade paket kapan saja sesuai kebutuhan bisnis Anda.",
              },
              {
                q: "Apakah ada garansi uang kembali?",
                a: "Ya, kami menawarkan jaminan uang kembali 30 hari tanpa pertanyaan.",
              },
              {
                q: "Apa yang termasuk dalam support?",
                a: "Semua paket termasuk email support. Professional dan Enterprise termasuk priority support 24/7.",
              },
            ].map((faq, idx) => (
              <Card key={idx} className="border-border/50">
                <CardHeader>
                  <CardTitle className="text-lg">{faq.q}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">{faq.a}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      <Footer />
    </div>
  )
}
