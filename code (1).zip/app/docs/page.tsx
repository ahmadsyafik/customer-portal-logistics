"use client"

import Link from "next/link"
import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { BookOpen, Code, Database, Shield, ArrowRight } from "lucide-react"

export default function DocsPage() {
  const docSections = [
    {
      icon: BookOpen,
      title: "Getting Started",
      description: "Panduan cepat untuk memulai menggunakan ShipSmart",
      links: ["Instalasi & Setup", "Konfigurasi Dasar", "Tutorial Pertama"],
    },
    {
      icon: Code,
      title: "API Reference",
      description: "Dokumentasi lengkap REST API dan SDK kami",
      links: ["Authentication", "Endpoints", "Error Handling", "Rate Limiting"],
    },
    {
      icon: Database,
      title: "Data Management",
      description: "Panduan manajemen data dan integrasi database",
      links: ["Database Setup", "Data Migration", "Backup & Recovery", "Data Security"],
    },
    {
      icon: Shield,
      title: "Security",
      description: "Best practices keamanan dan compliance",
      links: ["Security Guidelines", "Encryption", "Access Control", "Audit Logs"],
    },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-muted/20">
      <Navbar />

      {/* Header */}
      <section className="pt-20 pb-12 px-4 md:px-6">
        <div className="max-w-7xl mx-auto text-center space-y-4">
          <h1 className="text-5xl md:text-6xl font-bold text-balance">Dokumentasi</h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Panduan lengkap dan resources untuk menggunakan ShipSmart
          </p>
        </div>
      </section>

      {/* Quick Search */}
      <section className="py-12 px-4 md:px-6">
        <div className="max-w-4xl mx-auto">
          <div className="flex gap-2">
            <input
              type="text"
              placeholder="Cari dokumentasi..."
              className="flex-1 px-4 py-3 rounded-lg border border-border bg-background placeholder-muted-foreground"
            />
            <Button>Cari</Button>
          </div>
        </div>
      </section>

      {/* Doc Sections */}
      <section className="py-20 px-4 md:px-6">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-2 gap-8">
            {docSections.map((section, idx) => {
              const Icon = section.icon
              return (
                <Card key={idx} className="border-border/50 hover:border-accent/50 transition-colors cursor-pointer">
                  <CardHeader>
                    <div className="w-12 h-12 rounded-lg bg-accent/10 flex items-center justify-center mb-4">
                      <Icon className="w-6 h-6 text-accent" />
                    </div>
                    <CardTitle>{section.title}</CardTitle>
                    <CardDescription>{section.description}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-2">
                      {section.links.map((link, linkIdx) => (
                        <li key={linkIdx} className="text-sm">
                          <Link href="#" className="text-accent hover:underline flex items-center gap-2">
                            {link}
                            <ArrowRight className="w-3 h-3" />
                          </Link>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        </div>
      </section>

      {/* Popular Topics */}
      <section className="py-20 px-4 md:px-6 bg-card/50">
        <div className="max-w-7xl mx-auto space-y-8">
          <div className="text-center space-y-2">
            <h2 className="text-3xl font-bold">Topik Populer</h2>
            <p className="text-muted-foreground">Panduan yang paling sering dicari</p>
          </div>

          <div className="grid md:grid-cols-3 gap-4">
            {[
              "Cara Membuat Pengiriman Pertama",
              "Setup API Integration",
              "Troubleshooting Tracking",
              "Manajemen User & Permission",
              "Export Data & Reporting",
              "Upgrade Plan",
            ].map((topic, idx) => (
              <Link key={idx} href="#" className="group">
                <Card className="border-border/50 hover:border-accent/50 transition-colors h-full">
                  <CardContent className="p-6 flex items-center justify-between">
                    <span className="font-medium group-hover:text-accent transition-colors">{topic}</span>
                    <ArrowRight className="w-4 h-4 text-muted-foreground group-hover:text-accent transition-colors" />
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 px-4 md:px-6">
        <div className="max-w-4xl mx-auto text-center space-y-8">
          <h2 className="text-3xl font-bold">Butuh Bantuan?</h2>
          <p className="text-muted-foreground">Hubungi tim support kami yang siap membantu Anda 24/7</p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg">Email Support</Button>
            <Button size="lg" variant="outline">
              Live Chat
            </Button>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  )
}
