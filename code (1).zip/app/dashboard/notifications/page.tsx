"use client"

import { useState } from "react"
import { DashboardNavbar } from "@/components/dashboard-navbar"
import { DashboardSidebar } from "@/components/dashboard-sidebar"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { CheckCircle2, AlertCircle, Info, Trash2 } from "lucide-react"

export default function NotificationsPage() {
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [notifications, setNotifications] = useState([
    {
      id: 1,
      type: "success",
      title: "Pengiriman Berhasil Dikirim",
      message: "Kontainer MV-001 telah tiba di pelabuhan tujuan Surabaya",
      time: "2 jam lalu",
      read: false,
    },
    {
      id: 2,
      type: "warning",
      title: "Keterlambatan Jadwal",
      message: "Kapal MV-002 mengalami penundaan 6 jam karena cuaca buruk",
      time: "5 jam lalu",
      read: false,
    },
    {
      id: 3,
      type: "info",
      title: "Update Dokumentasi",
      message: "Dokumen ekspor untuk shipment SHP-2024-001 telah disetujui",
      time: "1 hari lalu",
      read: true,
    },
    {
      id: 4,
      type: "success",
      title: "Pembayaran Dikonfirmasi",
      message: "Pembayaran Rp 15.000.000 untuk pengiriman INV-001 telah diterima",
      time: "2 hari lalu",
      read: true,
    },
    {
      id: 5,
      type: "warning",
      title: "Pembayaran Tertunda",
      message: "Invoice INV-002 telah jatuh tempo. Harap lakukan pembayaran segera",
      time: "3 hari lalu",
      read: true,
    },
    {
      id: 6,
      type: "info",
      title: "Laporan Bulanan Tersedia",
      message: "Laporan kinerja logistik bulan November 2024 telah siap diunduh",
      time: "1 minggu lalu",
      read: true,
    },
  ])

  const deleteNotification = (id: number) => {
    setNotifications(notifications.filter((n) => n.id !== id))
  }

  const getIcon = (type: string) => {
    switch (type) {
      case "success":
        return <CheckCircle2 className="w-5 h-5 text-green-600" />
      case "warning":
        return <AlertCircle className="w-5 h-5 text-yellow-600" />
      default:
        return <Info className="w-5 h-5 text-blue-600" />
    }
  }

  const unreadCount = notifications.filter((n) => !n.read).length

  return (
    <div className="min-h-screen bg-background">
      <DashboardNavbar />
      <div className="flex">
        <DashboardSidebar isOpen={sidebarOpen} setIsOpen={setSidebarOpen} />

        <main className="flex-1">
          <div className="p-6 md:p-8 space-y-8">
            {/* Header */}
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-3xl md:text-4xl font-bold">Notifikasi</h1>
                <p className="text-muted-foreground">Kelola dan pantau semua notifikasi Anda</p>
              </div>
              {unreadCount > 0 && (
                <Badge variant="default" className="px-3 py-1.5">
                  {unreadCount} Baru
                </Badge>
              )}
            </div>

            {/* Tabs */}
            <Tabs defaultValue="all" className="w-full">
              <TabsList>
                <TabsTrigger value="all">Semua ({notifications.length})</TabsTrigger>
                <TabsTrigger value="unread">Belum Dibaca ({unreadCount})</TabsTrigger>
              </TabsList>

              {/* All Notifications */}
              <TabsContent value="all" className="space-y-4 mt-6">
                {notifications.length === 0 ? (
                  <Card className="border-border/50">
                    <CardContent className="flex flex-col items-center justify-center py-12">
                      <Info className="w-12 h-12 text-muted-foreground/50 mb-4" />
                      <p className="text-muted-foreground text-center">Tidak ada notifikasi</p>
                    </CardContent>
                  </Card>
                ) : (
                  notifications.map((notification) => (
                    <Card
                      key={notification.id}
                      className={`border-border/50 ${!notification.read ? "border-accent/30 bg-accent/5" : ""}`}
                    >
                      <CardContent className="p-4">
                        <div className="flex items-start gap-4">
                          <div className="mt-1">{getIcon(notification.type)}</div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-start justify-between gap-4">
                              <div className="flex-1">
                                <h3 className="font-semibold text-foreground">{notification.title}</h3>
                                <p className="text-sm text-muted-foreground mt-1">{notification.message}</p>
                                <p className="text-xs text-muted-foreground mt-2">{notification.time}</p>
                              </div>
                              <button
                                onClick={() => deleteNotification(notification.id)}
                                className="p-1.5 hover:bg-muted rounded-lg transition-colors flex-shrink-0"
                              >
                                <Trash2 className="w-4 h-4 text-muted-foreground" />
                              </button>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))
                )}
              </TabsContent>

              {/* Unread Notifications */}
              <TabsContent value="unread" className="space-y-4 mt-6">
                {notifications.filter((n) => !n.read).length === 0 ? (
                  <Card className="border-border/50">
                    <CardContent className="flex flex-col items-center justify-center py-12">
                      <Info className="w-12 h-12 text-muted-foreground/50 mb-4" />
                      <p className="text-muted-foreground text-center">Tidak ada notifikasi yang belum dibaca</p>
                    </CardContent>
                  </Card>
                ) : (
                  notifications
                    .filter((n) => !n.read)
                    .map((notification) => (
                      <Card key={notification.id} className="border-border/50 border-accent/30 bg-accent/5">
                        <CardContent className="p-4">
                          <div className="flex items-start gap-4">
                            <div className="mt-1">{getIcon(notification.type)}</div>
                            <div className="flex-1 min-w-0">
                              <div className="flex items-start justify-between gap-4">
                                <div className="flex-1">
                                  <h3 className="font-semibold text-foreground">{notification.title}</h3>
                                  <p className="text-sm text-muted-foreground mt-1">{notification.message}</p>
                                  <p className="text-xs text-muted-foreground mt-2">{notification.time}</p>
                                </div>
                                <button
                                  onClick={() => deleteNotification(notification.id)}
                                  className="p-1.5 hover:bg-muted rounded-lg transition-colors flex-shrink-0"
                                >
                                  <Trash2 className="w-4 h-4 text-muted-foreground" />
                                </button>
                              </div>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))
                )}
              </TabsContent>
            </Tabs>
          </div>
        </main>
      </div>
    </div>
  )
}
