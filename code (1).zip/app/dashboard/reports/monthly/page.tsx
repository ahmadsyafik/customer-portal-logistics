"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { DashboardNavbar } from "@/components/dashboard-navbar"
import { DashboardSidebar } from "@/components/dashboard-sidebar"
import { ReportChart } from "@/components/report-chart"
import { Download, ArrowLeft } from "lucide-react"

export default function MonthlyReportsPage() {
  const [sidebarOpen, setSidebarOpen] = useState(false)

  const monthlyData = {
    totalShipments: 128,
    successRate: 98.5,
    costSaving: 12,
    topServices: [
      { name: "Trucking", rating: 4.8, reviews: 245 },
      { name: "Stevedoring", rating: 4.6, reviews: 198 },
      { name: "Documentation", rating: 4.7, reviews: 156 },
      { name: "Warehouse", rating: 4.5, reviews: 89 },
    ],
  }

  return (
    <div className="min-h-screen bg-background">
      <DashboardNavbar />
      <div className="flex">
        <DashboardSidebar isOpen={sidebarOpen} setIsOpen={setSidebarOpen} />

        <main className="flex-1">
          <div className="p-6 md:p-8 space-y-8">
            {/* Header */}
            <div className="flex items-center justify-between gap-4">
              <div className="flex items-center gap-4">
                <Link href="/dashboard/reports">
                  <button className="p-2 hover:bg-muted rounded-lg transition-colors">
                    <ArrowLeft className="w-5 h-5" />
                  </button>
                </Link>
                <div>
                  <h1 className="text-3xl md:text-4xl font-bold">Laporan Bulanan</h1>
                  <p className="text-muted-foreground">Ringkasan performa November 2024</p>
                </div>
              </div>
              <Button className="gap-2">
                <Download className="w-4 h-4" />
                Export PDF
              </Button>
            </div>

            {/* Summary Stats */}
            <div className="grid md:grid-cols-3 gap-6">
              <Card className="border-border/50">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium">Total Pengiriman</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold flex items-baseline gap-2">
                    <span>{monthlyData.totalShipments}</span>
                    <span className="text-sm text-green-500">+12%</span>
                  </div>
                  <p className="text-xs text-muted-foreground mt-2">vs Oktober 114 pengiriman</p>
                </CardContent>
              </Card>

              <Card className="border-border/50">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium">On-Time Delivery</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold flex items-baseline gap-2">
                    <span>{monthlyData.successRate}%</span>
                    <span className="text-sm text-green-500">+2.3%</span>
                  </div>
                  <p className="text-xs text-muted-foreground mt-2">Pengiriman tepat waktu</p>
                </CardContent>
              </Card>

              <Card className="border-border/50">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium">Avg. Cost Saving</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold flex items-baseline gap-2">
                    <span>{monthlyData.costSaving}%</span>
                    <span className="text-sm text-green-500">+3.1%</span>
                  </div>
                  <p className="text-xs text-muted-foreground mt-2">Penghematan biaya operasional</p>
                </CardContent>
              </Card>
            </div>

            {/* Charts */}
            <div className="grid lg:grid-cols-2 gap-6">
              <Card className="border-border/50">
                <CardHeader>
                  <CardTitle>Performa Pengiriman</CardTitle>
                  <CardDescription>Ekspor vs Impor</CardDescription>
                </CardHeader>
                <CardContent>
                  <ReportChart type="shipment" />
                </CardContent>
              </Card>

              <Card className="border-border/50">
                <CardHeader>
                  <CardTitle>Efisiensi Waktu</CardTitle>
                  <CardDescription>Rata-rata waktu per tahap</CardDescription>
                </CardHeader>
                <CardContent>
                  <ReportChart type="efficiency" />
                </CardContent>
              </Card>
            </div>

            {/* Service Performance */}
            <Card className="border-border/50">
              <CardHeader>
                <CardTitle>Performa Layanan</CardTitle>
                <CardDescription>Kepuasan & rating layanan bulan November</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {monthlyData.topServices.map((service) => (
                  <div key={service.name} className="flex items-center justify-between p-3 bg-muted/30 rounded-lg">
                    <div>
                      <p className="font-semibold">{service.name}</p>
                      <p className="text-xs text-muted-foreground">{service.reviews} ulasan bulan ini</p>
                    </div>
                    <div className="text-right">
                      <p className="font-bold text-lg text-accent">{service.rating}</p>
                      <p className="text-xs text-muted-foreground">/ 5.0</p>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Weekly Breakdown */}
            <Card className="border-border/50">
              <CardHeader>
                <CardTitle>Perbandingan Mingguan</CardTitle>
                <CardDescription>Data breakdown per minggu dalam bulan November 2024</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {[
                    { week: "Minggu 1 (1-7 Nov)", shipments: 32, success: 96.9 },
                    { week: "Minggu 2 (8-14 Nov)", shipments: 31, success: 98.1 },
                    { week: "Minggu 3 (15-21 Nov)", shipments: 34, success: 99.2 },
                    { week: "Minggu 4 (22-30 Nov)", shipments: 31, success: 98.4 },
                  ].map((item) => (
                    <div key={item.week} className="flex items-center justify-between p-3 bg-muted/30 rounded-lg">
                      <div>
                        <p className="font-semibold">{item.week}</p>
                      </div>
                      <div className="flex gap-8">
                        <div className="text-right">
                          <p className="text-xs text-muted-foreground">Pengiriman</p>
                          <p className="font-bold">{item.shipments}</p>
                        </div>
                        <div className="text-right">
                          <p className="text-xs text-muted-foreground">Success Rate</p>
                          <p className="font-bold text-green-500">{item.success}%</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </main>
      </div>
    </div>
  )
}
