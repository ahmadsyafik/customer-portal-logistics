"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { DashboardNavbar } from "@/components/dashboard-navbar"
import { DashboardSidebar } from "@/components/dashboard-sidebar"
import { ReportChart } from "@/components/report-chart"
import { Download, ChevronRight } from "lucide-react"

export default function ReportsPage() {
  const [sidebarOpen, setSidebarOpen] = useState(false)

  return (
    <div className="min-h-screen bg-background">
      <DashboardNavbar />
      <div className="flex">
        <DashboardSidebar isOpen={sidebarOpen} setIsOpen={setSidebarOpen} />

        <main className="flex-1">
          <div className="p-6 md:p-8 space-y-8">
            {/* Header */}
            <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
              <div>
                <h1 className="text-3xl md:text-4xl font-bold">Laporan & Analitik</h1>
                <p className="text-muted-foreground">Analisis kinerja operasional dan logistik Anda</p>
              </div>
              <Button className="gap-2">
                <Download className="w-4 h-4" />
                Export PDF
              </Button>
            </div>

            <div className="grid md:grid-cols-3 gap-6">
              <Link href="/dashboard/reports/weekly">
                <Card className="border-border/50 hover:border-accent/50 transition-colors cursor-pointer h-full">
                  <CardHeader>
                    <CardTitle className="flex items-center justify-between">
                      <span>Laporan Mingguan</span>
                      <ChevronRight className="w-5 h-5" />
                    </CardTitle>
                    <CardDescription>Data performa minggu ini</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-baseline gap-2">
                      <p className="text-3xl font-bold">32</p>
                      <p className="text-muted-foreground">pengiriman</p>
                    </div>
                  </CardContent>
                </Card>
              </Link>

              <Link href="/dashboard/reports/monthly">
                <Card className="border-border/50 hover:border-secondary/50 transition-colors cursor-pointer h-full">
                  <CardHeader>
                    <CardTitle className="flex items-center justify-between">
                      <span>Laporan Bulanan</span>
                      <ChevronRight className="w-5 h-5" />
                    </CardTitle>
                    <CardDescription>Data performa bulan ini</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-baseline gap-2">
                      <p className="text-3xl font-bold">128</p>
                      <p className="text-muted-foreground">pengiriman</p>
                    </div>
                  </CardContent>
                </Card>
              </Link>

              <Link href="/dashboard/reports/yearly">
                <Card className="border-border/50 hover:border-primary/50 transition-colors cursor-pointer h-full">
                  <CardHeader>
                    <CardTitle className="flex items-center justify-between">
                      <span>Laporan Tahunan</span>
                      <ChevronRight className="w-5 h-5" />
                    </CardTitle>
                    <CardDescription>Data performa tahun ini</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-baseline gap-2">
                      <p className="text-3xl font-bold">1,536</p>
                      <p className="text-muted-foreground">pengiriman</p>
                    </div>
                  </CardContent>
                </Card>
              </Link>
            </div>

            {/* Summary Stats */}
            <div className="grid md:grid-cols-3 gap-6">
              <Card className="border-border/50">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium">Total Pengiriman</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold flex items-baseline gap-2">
                    <span>128</span>
                    <span className="text-sm text-green-500">+12%</span>
                  </div>
                  <p className="text-xs text-muted-foreground mt-2">vs periode sebelumnya</p>
                </CardContent>
              </Card>

              <Card className="border-border/50">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium">On-Time Delivery</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold flex items-baseline gap-2">
                    <span>98.5%</span>
                    <span className="text-sm text-green-500">+2.3%</span>
                  </div>
                  <p className="text-xs text-muted-foreground mt-2">Pengiriman tepat waktu</p>
                </CardContent>
              </Card>

              <Card className="border-border/50">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium">Avg. Cost Saving</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold flex items-baseline gap-2">
                    <span>12%</span>
                    <span className="text-sm text-green-500">+3.1%</span>
                  </div>
                  <p className="text-xs text-muted-foreground mt-2">Penghematan biaya operasional</p>
                </CardContent>
              </Card>
            </div>

            {/* Charts */}
            <div className="grid lg:grid-cols-2 gap-6">
              <Card className="border-border/50">
                <CardHeader>
                  <CardTitle>Performa Pengiriman</CardTitle>
                  <CardDescription>Ekspor vs Impor</CardDescription>
                </CardHeader>
                <CardContent>
                  <ReportChart type="shipment" />
                </CardContent>
              </Card>

              <Card className="border-border/50">
                <CardHeader>
                  <CardTitle>Efisiensi Waktu</CardTitle>
                  <CardDescription>Rata-rata waktu per tahap</CardDescription>
                </CardHeader>
                <CardContent>
                  <ReportChart type="efficiency" />
                </CardContent>
              </Card>
            </div>

            {/* Service Performance */}
            <Card className="border-border/50">
              <CardHeader>
                <CardTitle>Performa Layanan</CardTitle>
                <CardDescription>Kepuasan & rating layanan</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {[
                  { name: "Trucking", rating: 4.8, reviews: 245 },
                  { name: "Stevedoring", rating: 4.6, reviews: 198 },
                  { name: "Documentation", rating: 4.7, reviews: 156 },
                  { name: "Warehouse", rating: 4.5, reviews: 89 },
                ].map((service) => (
                  <div key={service.name} className="flex items-center justify-between p-3 bg-muted/30 rounded-lg">
                    <div>
                      <p className="font-semibold">{service.name}</p>
                      <p className="text-xs text-muted-foreground">{service.reviews} ulasan</p>
                    </div>
                    <div className="text-right">
                      <p className="font-bold text-lg text-accent">{service.rating}</p>
                      <p className="text-xs text-muted-foreground">/ 5.0</p>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>
        </main>
      </div>
    </div>
  )
}
