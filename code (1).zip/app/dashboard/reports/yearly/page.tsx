"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { DashboardNavbar } from "@/components/dashboard-navbar"
import { DashboardSidebar } from "@/components/dashboard-sidebar"
import { ReportChart } from "@/components/report-chart"
import { Download, ArrowLeft } from "lucide-react"

export default function YearlyReportsPage() {
  const [sidebarOpen, setSidebarOpen] = useState(false)

  const yearlyData = {
    totalShipments: 1456,
    successRate: 98.2,
    costSaving: 15.3,
    topServices: [
      { name: "Trucking", rating: 4.8, reviews: 2845 },
      { name: "Stevedoring", rating: 4.7, reviews: 2234 },
      { name: "Documentation", rating: 4.6, reviews: 1876 },
      { name: "Warehouse", rating: 4.5, reviews: 1034 },
    ],
  }

  return (
    <div className="min-h-screen bg-background">
      <DashboardNavbar />
      <div className="flex">
        <DashboardSidebar isOpen={sidebarOpen} setIsOpen={setSidebarOpen} />

        <main className="flex-1">
          <div className="p-6 md:p-8 space-y-8">
            {/* Header */}
            <div className="flex items-center justify-between gap-4">
              <div className="flex items-center gap-4">
                <Link href="/dashboard/reports">
                  <button className="p-2 hover:bg-muted rounded-lg transition-colors">
                    <ArrowLeft className="w-5 h-5" />
                  </button>
                </Link>
                <div>
                  <h1 className="text-3xl md:text-4xl font-bold">Laporan Tahunan</h1>
                  <p className="text-muted-foreground">Ringkasan performa tahun 2024</p>
                </div>
              </div>
              <Button className="gap-2">
                <Download className="w-4 h-4" />
                Export PDF
              </Button>
            </div>

            {/* Summary Stats */}
            <div className="grid md:grid-cols-3 gap-6">
              <Card className="border-border/50">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium">Total Pengiriman</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold flex items-baseline gap-2">
                    <span>{yearlyData.totalShipments}</span>
                    <span className="text-sm text-green-500">+18%</span>
                  </div>
                  <p className="text-xs text-muted-foreground mt-2">vs 2023: 1.234 pengiriman</p>
                </CardContent>
              </Card>

              <Card className="border-border/50">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium">On-Time Delivery</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold flex items-baseline gap-2">
                    <span>{yearlyData.successRate}%</span>
                    <span className="text-sm text-green-500">+2.8%</span>
                  </div>
                  <p className="text-xs text-muted-foreground mt-2">Pengiriman tepat waktu</p>
                </CardContent>
              </Card>

              <Card className="border-border/50">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium">Avg. Cost Saving</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold flex items-baseline gap-2">
                    <span>{yearlyData.costSaving}%</span>
                    <span className="text-sm text-green-500">+4.2%</span>
                  </div>
                  <p className="text-xs text-muted-foreground mt-2">Penghematan biaya operasional</p>
                </CardContent>
              </Card>
            </div>

            {/* Charts */}
            <div className="grid lg:grid-cols-2 gap-6">
              <Card className="border-border/50">
                <CardHeader>
                  <CardTitle>Performa Pengiriman</CardTitle>
                  <CardDescription>Ekspor vs Impor per kuartal</CardDescription>
                </CardHeader>
                <CardContent>
                  <ReportChart type="shipment" />
                </CardContent>
              </Card>

              <Card className="border-border/50">
                <CardHeader>
                  <CardTitle>Efisiensi Waktu</CardTitle>
                  <CardDescription>Rata-rata waktu per tahap</CardDescription>
                </CardHeader>
                <CardContent>
                  <ReportChart type="efficiency" />
                </CardContent>
              </Card>
            </div>

            {/* Service Performance */}
            <Card className="border-border/50">
              <CardHeader>
                <CardTitle>Performa Layanan</CardTitle>
                <CardDescription>Kepuasan & rating layanan sepanjang tahun 2024</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {yearlyData.topServices.map((service) => (
                  <div key={service.name} className="flex items-center justify-between p-3 bg-muted/30 rounded-lg">
                    <div>
                      <p className="font-semibold">{service.name}</p>
                      <p className="text-xs text-muted-foreground">{service.reviews} ulasan tahun ini</p>
                    </div>
                    <div className="text-right">
                      <p className="font-bold text-lg text-accent">{service.rating}</p>
                      <p className="text-xs text-muted-foreground">/ 5.0</p>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Monthly Breakdown */}
            <Card className="border-border/50">
              <CardHeader>
                <CardTitle>Perbandingan Bulanan</CardTitle>
                <CardDescription>Data breakdown per bulan dalam tahun 2024</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 gap-3">
                  {[
                    { month: "Januari", shipments: 128, success: 97.5 },
                    { month: "Februari", shipments: 132, success: 97.8 },
                    { month: "Maret", shipments: 135, success: 98.1 },
                    { month: "April", shipments: 130, success: 97.9 },
                    { month: "Mei", shipments: 138, success: 98.3 },
                    { month: "Juni", shipments: 142, success: 98.5 },
                    { month: "Juli", shipments: 140, success: 98.2 },
                    { month: "Agustus", shipments: 139, success: 98.0 },
                    { month: "September", shipments: 136, success: 98.1 },
                    { month: "Oktober", shipments: 134, success: 98.4 },
                    { month: "November", shipments: 128, success: 98.5 },
                    { month: "Desember", shipments: 144, success: 98.8 },
                  ].map((item) => (
                    <div key={item.month} className="flex items-center justify-between p-3 bg-muted/30 rounded-lg">
                      <div>
                        <p className="font-semibold text-sm">{item.month}</p>
                      </div>
                      <div className="flex gap-4">
                        <div className="text-right">
                          <p className="text-xs text-muted-foreground">Pengiriman</p>
                          <p className="font-bold text-sm">{item.shipments}</p>
                        </div>
                        <div className="text-right">
                          <p className="text-xs text-muted-foreground">Success</p>
                          <p className="font-bold text-sm text-green-500">{item.success}%</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </main>
      </div>
    </div>
  )
}
