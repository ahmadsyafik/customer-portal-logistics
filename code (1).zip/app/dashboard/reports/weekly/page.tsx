"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { DashboardNavbar } from "@/components/dashboard-navbar"
import { DashboardSidebar } from "@/components/dashboard-sidebar"
import { ReportChart } from "@/components/report-chart"
import { Download, ArrowLeft } from "lucide-react"

export default function WeeklyReportsPage() {
  const [sidebarOpen, setSidebarOpen] = useState(false)

  const weeklyData = {
    totalShipments: 32,
    successRate: 96.9,
    costSaving: 8.5,
    topServices: [
      { name: "Trucking", rating: 4.8, reviews: 65 },
      { name: "Documentation", rating: 4.7, reviews: 42 },
      { name: "Stevedoring", rating: 4.6, reviews: 38 },
      { name: "Warehouse", rating: 4.5, reviews: 22 },
    ],
  }

  return (
    <div className="min-h-screen bg-background">
      <DashboardNavbar />
      <div className="flex">
        <DashboardSidebar isOpen={sidebarOpen} setIsOpen={setSidebarOpen} />

        <main className="flex-1">
          <div className="p-6 md:p-8 space-y-8">
            {/* Header */}
            <div className="flex items-center justify-between gap-4">
              <div className="flex items-center gap-4">
                <Link href="/dashboard/reports">
                  <button className="p-2 hover:bg-muted rounded-lg transition-colors">
                    <ArrowLeft className="w-5 h-5" />
                  </button>
                </Link>
                <div>
                  <h1 className="text-3xl md:text-4xl font-bold">Laporan Mingguan</h1>
                  <p className="text-muted-foreground">Ringkasan performa minggu ini (1-7 November 2024)</p>
                </div>
              </div>
              <Button className="gap-2">
                <Download className="w-4 h-4" />
                Export PDF
              </Button>
            </div>

            {/* Summary Stats */}
            <div className="grid md:grid-cols-3 gap-6">
              <Card className="border-border/50">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium">Total Pengiriman</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold flex items-baseline gap-2">
                    <span>{weeklyData.totalShipments}</span>
                    <span className="text-sm text-green-500">+8%</span>
                  </div>
                  <p className="text-xs text-muted-foreground mt-2">minggu lalu 29 pengiriman</p>
                </CardContent>
              </Card>

              <Card className="border-border/50">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium">Success Rate</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold flex items-baseline gap-2">
                    <span>{weeklyData.successRate}%</span>
                    <span className="text-sm text-green-500">+1.2%</span>
                  </div>
                  <p className="text-xs text-muted-foreground mt-2">1 pengiriman gagal</p>
                </CardContent>
              </Card>

              <Card className="border-border/50">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium">Avg. Cost Saving</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold flex items-baseline gap-2">
                    <span>{weeklyData.costSaving}%</span>
                    <span className="text-sm text-green-500">+2.1%</span>
                  </div>
                  <p className="text-xs text-muted-foreground mt-2">Rp 4.250.000 penghematan</p>
                </CardContent>
              </Card>
            </div>

            {/* Charts */}
            <div className="grid lg:grid-cols-2 gap-6">
              <Card className="border-border/50">
                <CardHeader>
                  <CardTitle>Performa Harian</CardTitle>
                  <CardDescription>Tren pengiriman per hari</CardDescription>
                </CardHeader>
                <CardContent>
                  <ReportChart type="shipment" />
                </CardContent>
              </Card>

              <Card className="border-border/50">
                <CardHeader>
                  <CardTitle>Efisiensi Proses</CardTitle>
                  <CardDescription>Rata-rata waktu per tahap</CardDescription>
                </CardHeader>
                <CardContent>
                  <ReportChart type="efficiency" />
                </CardContent>
              </Card>
            </div>

            {/* Service Performance */}
            <Card className="border-border/50">
              <CardHeader>
                <CardTitle>Performa Layanan</CardTitle>
                <CardDescription>Rating kepuasan pelanggan minggu ini</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {weeklyData.topServices.map((service) => (
                  <div key={service.name} className="flex items-center justify-between p-3 bg-muted/30 rounded-lg">
                    <div>
                      <p className="font-semibold">{service.name}</p>
                      <p className="text-xs text-muted-foreground">{service.reviews} rating minggu ini</p>
                    </div>
                    <div className="text-right">
                      <p className="font-bold text-lg text-accent">{service.rating}</p>
                      <p className="text-xs text-muted-foreground">/ 5.0</p>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>
        </main>
      </div>
    </div>
  )
}
