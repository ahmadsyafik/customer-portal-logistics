"use client"

import { useState } from "react"
import { DashboardNavbar } from "@/components/dashboard-navbar"
import { DashboardSidebar } from "@/components/dashboard-sidebar"
import { ImportStepper } from "@/components/import-stepper"
import { ImportRequestForm } from "@/components/import-forms/request-form"
import { ImportVerificationForm } from "@/components/import-forms/verification-form"
import { ImportSchedulingForm } from "@/components/import-forms/scheduling-form"

export default function ImportPage() {
  const [currentStep, setCurrentStep] = useState<"request" | "verification" | "scheduling">("request")
  const [formData, setFormData] = useState({
    importer: "",
    importerEmail: "",
    importerPhone: "",
    shipper: "",
    origin: "",
    goodsType: "",
    quantity: "",
    weight: "",
    containerType: "",
    vesselName: "",
    eta: "",
    hsCode: "",
    advancePayment: "",
    documentStatus: "pending" as "pending" | "approved" | "rejected",
    dischargingSchedule: "",
    truckPickupTime: "",
    gatePassRequested: false,
  })

  const handleStepChange = (step: "request" | "verification" | "scheduling") => {
    setCurrentStep(step)
  }

  const handleFormUpdate = (data: Partial<typeof formData>) => {
    setFormData((prev) => ({ ...prev, ...data }))
  }

  return (
    <div className="min-h-screen bg-background">
      <DashboardNavbar />
      <div className="flex">
        <DashboardSidebar isOpen={true} setIsOpen={() => {}} />

        <main className="flex-1">
          <div className="p-6 md:p-8 space-y-8">
            {/* Header */}
            <div>
              <h1 className="text-3xl md:text-4xl font-bold">Proses Impor Barang</h1>
              <p className="text-muted-foreground">Kelola impor barang Anda melalui tiga tahap terstruktur</p>
            </div>

            {/* Stepper */}
            <ImportStepper currentStep={currentStep} />

            {/* Form Content */}
            <div className="max-w-4xl">
              {currentStep === "request" && (
                <ImportRequestForm
                  data={formData}
                  onUpdate={handleFormUpdate}
                  onNext={() => handleStepChange("verification")}
                />
              )}

              {currentStep === "verification" && (
                <ImportVerificationForm
                  data={formData}
                  onUpdate={handleFormUpdate}
                  onNext={() => handleStepChange("scheduling")}
                  onBack={() => handleStepChange("request")}
                />
              )}

              {currentStep === "scheduling" && (
                <ImportSchedulingForm
                  data={formData}
                  onUpdate={handleFormUpdate}
                  onBack={() => handleStepChange("verification")}
                />
              )}
            </div>
          </div>
        </main>
      </div>
    </div>
  )
}
