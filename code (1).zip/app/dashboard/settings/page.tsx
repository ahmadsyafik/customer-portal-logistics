"use client"

import { useState } from "react"
import { DashboardNavbar } from "@/components/dashboard-navbar"
import { DashboardSidebar } from "@/components/dashboard-sidebar"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Switch } from "@/components/ui/switch"
import { User, Bell, Lock, Building } from "lucide-react"

export default function SettingsPage() {
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [formData, setFormData] = useState({
    company: "PT Maju Jaya Logistik",
    email: "info@majulogistik.com",
    phone: "+62-21-1234567",
    address: "Jl. Merdeka No. 123, Jakarta",
    notifications: {
      email: true,
      sms: true,
      shipmentUpdates: true,
      paymentReminders: true,
    },
  })

  const handleInputChange = (field: string, value: string) => {
    setFormData((prev) => ({
      ...prev,
      [field]: value,
    }))
  }

  const handleNotificationChange = (field: string, value: boolean) => {
    setFormData((prev) => ({
      ...prev,
      notifications: {
        ...prev.notifications,
        [field]: value,
      },
    }))
  }

  return (
    <div className="min-h-screen bg-background">
      <DashboardNavbar />
      <div className="flex">
        <DashboardSidebar isOpen={sidebarOpen} setIsOpen={setSidebarOpen} />

        <main className="flex-1">
          <div className="p-6 md:p-8 space-y-8">
            {/* Header */}
            <div>
              <h1 className="text-3xl md:text-4xl font-bold">Pengaturan</h1>
              <p className="text-muted-foreground">Kelola profil, keamanan, dan preferensi Anda</p>
            </div>

            {/* Settings Tabs */}
            <Tabs defaultValue="profile" className="w-full">
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="profile" className="flex items-center gap-2">
                  <User className="w-4 h-4" />
                  <span className="hidden sm:inline">Profil</span>
                </TabsTrigger>
                <TabsTrigger value="company" className="flex items-center gap-2">
                  <Building className="w-4 h-4" />
                  <span className="hidden sm:inline">Perusahaan</span>
                </TabsTrigger>
                <TabsTrigger value="notifications" className="flex items-center gap-2">
                  <Bell className="w-4 h-4" />
                  <span className="hidden sm:inline">Notifikasi</span>
                </TabsTrigger>
                <TabsTrigger value="security" className="flex items-center gap-2">
                  <Lock className="w-4 h-4" />
                  <span className="hidden sm:inline">Keamanan</span>
                </TabsTrigger>
              </TabsList>

              {/* Profile Tab */}
              <TabsContent value="profile" className="space-y-6 mt-6">
                <Card className="border-border/50">
                  <CardHeader>
                    <CardTitle>Informasi Akun</CardTitle>
                    <CardDescription>Update informasi akun pribadi Anda</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="email">Email</Label>
                      <Input
                        id="email"
                        value={formData.email}
                        onChange={(e) => handleInputChange("email", e.target.value)}
                        placeholder="email@example.com"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="phone">Nomor Telepon</Label>
                      <Input
                        id="phone"
                        value={formData.phone}
                        onChange={(e) => handleInputChange("phone", e.target.value)}
                        placeholder="+62-21-1234567"
                      />
                    </div>
                    <Button className="mt-4">Simpan Perubahan</Button>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Company Tab */}
              <TabsContent value="company" className="space-y-6 mt-6">
                <Card className="border-border/50">
                  <CardHeader>
                    <CardTitle>Informasi Perusahaan</CardTitle>
                    <CardDescription>Update detail perusahaan Anda</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="company">Nama Perusahaan</Label>
                      <Input
                        id="company"
                        value={formData.company}
                        onChange={(e) => handleInputChange("company", e.target.value)}
                        placeholder="Nama Perusahaan"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="address">Alamat</Label>
                      <Input
                        id="address"
                        value={formData.address}
                        onChange={(e) => handleInputChange("address", e.target.value)}
                        placeholder="Jalan, No., Kota"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="phone-company">Telepon Perusahaan</Label>
                      <Input
                        id="phone-company"
                        value={formData.phone}
                        onChange={(e) => handleInputChange("phone", e.target.value)}
                        placeholder="+62-21-1234567"
                      />
                    </div>
                    <Button className="mt-4">Simpan Perubahan</Button>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Notifications Tab */}
              <TabsContent value="notifications" className="space-y-6 mt-6">
                <Card className="border-border/50">
                  <CardHeader>
                    <CardTitle>Preferensi Notifikasi</CardTitle>
                    <CardDescription>Atur bagaimana Anda ingin menerima notifikasi</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-semibold">Email Notifikasi</p>
                        <p className="text-sm text-muted-foreground">Terima notifikasi melalui email</p>
                      </div>
                      <Switch
                        checked={formData.notifications.email}
                        onCheckedChange={(value) => handleNotificationChange("email", value)}
                      />
                    </div>

                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-semibold">SMS Notifikasi</p>
                        <p className="text-sm text-muted-foreground">Terima notifikasi melalui SMS</p>
                      </div>
                      <Switch
                        checked={formData.notifications.sms}
                        onCheckedChange={(value) => handleNotificationChange("sms", value)}
                      />
                    </div>

                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-semibold">Update Pengiriman</p>
                        <p className="text-sm text-muted-foreground">Notifikasi real-time untuk pengiriman Anda</p>
                      </div>
                      <Switch
                        checked={formData.notifications.shipmentUpdates}
                        onCheckedChange={(value) => handleNotificationChange("shipmentUpdates", value)}
                      />
                    </div>

                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-semibold">Pengingat Pembayaran</p>
                        <p className="text-sm text-muted-foreground">Pengingat untuk pembayaran yang jatuh tempo</p>
                      </div>
                      <Switch
                        checked={formData.notifications.paymentReminders}
                        onCheckedChange={(value) => handleNotificationChange("paymentReminders", value)}
                      />
                    </div>

                    <Button className="mt-4">Simpan Preferensi</Button>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Security Tab */}
              <TabsContent value="security" className="space-y-6 mt-6">
                <Card className="border-border/50">
                  <CardHeader>
                    <CardTitle>Keamanan Akun</CardTitle>
                    <CardDescription>Kelola keamanan dan privasi akun Anda</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="password">Password Saat Ini</Label>
                      <Input id="password" type="password" placeholder="••••••••" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="new-password">Password Baru</Label>
                      <Input id="new-password" type="password" placeholder="••••••••" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="confirm-password">Konfirmasi Password</Label>
                      <Input id="confirm-password" type="password" placeholder="••••••••" />
                    </div>
                    <Button className="mt-4">Ubah Password</Button>
                  </CardContent>
                </Card>

                <Card className="border-border/50 border-red-200 bg-red-50/50">
                  <CardHeader>
                    <CardTitle className="text-red-700">Zona Berbahaya</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-muted-foreground mb-4">
                      Hapus akun Anda secara permanen. Tindakan ini tidak dapat dibatalkan.
                    </p>
                    <Button variant="destructive">Hapus Akun</Button>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </main>
      </div>
    </div>
  )
}
