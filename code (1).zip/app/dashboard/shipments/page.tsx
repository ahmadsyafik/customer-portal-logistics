"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { DashboardNavbar } from "@/components/dashboard-navbar"
import { DashboardSidebar } from "@/components/dashboard-sidebar"
import { ShipmentList } from "@/components/shipment-list"

export default function ShipmentsPage() {
  const [filter, setFilter] = useState<"all" | "export" | "import">("all")

  const shipments = [
    {
      id: "SHP-001",
      type: "Ekspor" as const,
      status: "In Transit",
      destination: "Singapore",
      progress: 65,
      vesselName: "Maersk Seatrade",
      eta: "2025-01-15",
      cargo: "Kontainer Elektronik",
    },
    {
      id: "SHP-002",
      type: "Ekspor" as const,
      status: "Delivered",
      destination: "Rotterdam",
      progress: 100,
      vesselName: "MSC Gulsun",
      eta: "2024-12-20",
      cargo: "Palm Oil",
    },
    {
      id: "IMP-001",
      type: "Impor" as const,
      status: "Customs",
      destination: "Jakarta",
      progress: 45,
      vesselName: "Ever Given",
      eta: "2025-01-18",
      cargo: "Raw Materials",
    },
    {
      id: "IMP-002",
      type: "Impor" as const,
      status: "Loading",
      destination: "Surabaya",
      progress: 25,
      vesselName: "ONE Apus",
      eta: "2025-01-10",
      cargo: "Industrial Equipment",
    },
  ]

  const filteredShipments = shipments.filter((s) => {
    if (filter === "all") return true
    if (filter === "export") return s.type === "Ekspor"
    if (filter === "import") return s.type === "Impor"
    return true
  })

  return (
    <div className="min-h-screen bg-background">
      <DashboardNavbar />
      <div className="flex">
        <DashboardSidebar isOpen={true} setIsOpen={() => {}} />

        <main className="flex-1">
          <div className="p-6 md:p-8 space-y-8">
            {/* Header */}
            <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
              <div>
                <h1 className="text-3xl md:text-4xl font-bold">Daftar Lengkap Pengiriman</h1>
                <p className="text-muted-foreground">Kelola semua pengiriman ekspor dan impor</p>
              </div>
            </div>

            {/* Filters */}
            <div className="flex gap-2">
              {(["all", "export", "import"] as const).map((f) => (
                <button
                  key={f}
                  onClick={() => setFilter(f)}
                  className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                    filter === f ? "bg-accent text-white" : "bg-muted hover:bg-muted/80 text-muted-foreground"
                  }`}
                >
                  {f === "all" ? "Semua" : f === "export" ? "Ekspor" : "Impor"}
                </button>
              ))}
            </div>

            {/* Shipment List */}
            <Card className="border-border/50">
              <CardHeader>
                <CardTitle>Pengiriman ({filteredShipments.length})</CardTitle>
                <CardDescription>Daftar lengkap semua pengiriman</CardDescription>
              </CardHeader>
              <CardContent>
                <ShipmentList shipments={filteredShipments} />
              </CardContent>
            </Card>
          </div>
        </main>
      </div>
    </div>
  )
}
