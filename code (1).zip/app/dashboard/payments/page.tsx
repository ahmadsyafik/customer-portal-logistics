"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { DashboardNavbar } from "@/components/dashboard-navbar"
import { DashboardSidebar } from "@/components/dashboard-sidebar"
import { PaymentList } from "@/components/payment-list"
import { PaymentStats } from "@/components/payment-stats"
import { Download } from "lucide-react"

export default function PaymentsPage() {
  const [filter, setFilter] = useState<"all" | "pending" | "paid" | "overdue">("all")

  const payments = [
    {
      id: "INV-001",
      shipmentId: "SHP-001",
      type: "Ekspor",
      description: "Layanan Trucking + Stevedoring",
      amount: 25000000,
      status: "paid",
      dueDate: "2025-01-05",
      paidDate: "2025-01-04",
      invoiceDate: "2025-01-01",
    },
    {
      id: "INV-002",
      shipmentId: "SHP-002",
      type: "Ekspor",
      description: "Layanan Trucking",
      amount: 12500000,
      status: "pending",
      dueDate: "2025-01-20",
      paidDate: null,
      invoiceDate: "2025-01-15",
    },
    {
      id: "INV-003",
      shipmentId: "IMP-001",
      type: "Impor",
      description: "Layanan Bongkar + Dokumentasi",
      amount: 18000000,
      status: "overdue",
      dueDate: "2025-01-10",
      paidDate: null,
      invoiceDate: "2025-01-05",
    },
    {
      id: "INV-004",
      shipmentId: "IMP-002",
      type: "Impor",
      description: "Layanan Bongkar + Gate Pass",
      amount: 16500000,
      status: "paid",
      dueDate: "2025-01-15",
      paidDate: "2025-01-14",
      invoiceDate: "2025-01-10",
    },
  ]

  const filteredPayments = payments.filter((p) => {
    if (filter === "all") return true
    return p.status === filter
  })

  return (
    <div className="min-h-screen bg-background">
      <DashboardNavbar />
      <div className="flex">
        <DashboardSidebar isOpen={true} setIsOpen={() => {}} />

        <main className="flex-1">
          <div className="p-6 md:p-8 space-y-8">
            {/* Header */}
            <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
              <div>
                <h1 className="text-3xl md:text-4xl font-bold">Pembayaran & Penagihan</h1>
                <p className="text-muted-foreground">Kelola semua invoice dan pembayaran pengiriman</p>
              </div>
              <Button className="gap-2">
                <Download className="w-4 h-4" />
                Export Laporan
              </Button>
            </div>

            {/* Stats */}
            <PaymentStats />

            {/* Filters */}
            <div className="flex gap-2">
              {(["all", "pending", "paid", "overdue"] as const).map((f) => (
                <button
                  key={f}
                  onClick={() => setFilter(f)}
                  className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                    filter === f ? "bg-accent text-white" : "bg-muted hover:bg-muted/80 text-muted-foreground"
                  }`}
                >
                  {f === "all" ? "Semua" : f === "pending" ? "Tertunda" : f === "paid" ? "Dibayar" : "Terlambat"}
                </button>
              ))}
            </div>

            {/* Payment List */}
            <Card className="border-border/50">
              <CardHeader>
                <CardTitle>Daftar Invoice</CardTitle>
                <CardDescription>Invoice konsolidasi dari semua layanan</CardDescription>
              </CardHeader>
              <CardContent>
                <PaymentList payments={filteredPayments} />
              </CardContent>
            </Card>
          </div>
        </main>
      </div>
    </div>
  )
}
