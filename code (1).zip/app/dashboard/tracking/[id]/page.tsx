"use client"

import { useParams } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { DashboardNavbar } from "@/components/dashboard-navbar"
import { DashboardSidebar } from "@/components/dashboard-sidebar"
import { ShipmentTimeline } from "@/components/shipment-timeline"
import { AlertCircle, MapPin, Ship, TrendingUp } from "lucide-react"

export default function TrackingDetailPage() {
  const params = useParams()
  const shipmentId = params.id as string

  const isExport = shipmentId.startsWith("SHP")

  return (
    <div className="min-h-screen bg-background">
      <DashboardNavbar />
      <div className="flex">
        <DashboardSidebar isOpen={true} setIsOpen={() => {}} />

        <main className="flex-1">
          <div className="p-6 md:p-8 space-y-8">
            {/* Header */}
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-3xl md:text-4xl font-bold">Detail Pengiriman</h1>
                <p className="text-muted-foreground font-mono">{shipmentId}</p>
              </div>
              <div
                className={`px-4 py-2 rounded-lg font-semibold text-sm ${
                  isExport ? "bg-accent/10 text-accent" : "bg-secondary/10 text-secondary"
                }`}
              >
                {isExport ? "EKSPOR" : "IMPOR"}
              </div>
            </div>

            {/* Status Alert */}
            <div className="bg-secondary/5 border border-secondary/20 rounded-lg p-4 flex gap-3">
              <AlertCircle className="w-5 h-5 text-secondary flex-shrink-0 mt-0.5" />
              <div>
                <p className="font-semibold text-sm">Kapal Mengalami Keterlambatan</p>
                <p className="text-sm text-muted-foreground mt-1">
                  Kondisi laut bergelombang di Selat Malaka mengakibatkan kapal mundur 4 jam. ETA diperkirakan akan
                  mundur ke 2025-01-15 12:00.
                </p>
              </div>
            </div>

            {/* Quick Stats */}
            <div className="grid md:grid-cols-4 gap-4">
              <Card className="border-border/50">
                <CardContent className="pt-6">
                  <div className="flex items-start justify-between">
                    <div>
                      <p className="text-xs text-muted-foreground">Status</p>
                      <p className="font-bold text-lg mt-1">{isExport ? "In Transit" : "Customs"}</p>
                    </div>
                    <TrendingUp className={`w-5 h-5 ${isExport ? "text-accent" : "text-secondary"}`} />
                  </div>
                </CardContent>
              </Card>

              <Card className="border-border/50">
                <CardContent className="pt-6">
                  <div className="flex items-start justify-between">
                    <div>
                      <p className="text-xs text-muted-foreground">Lokasi</p>
                      <p className="font-bold text-sm mt-1">Selat Malaka</p>
                    </div>
                    <MapPin className="w-5 h-5 text-accent" />
                  </div>
                </CardContent>
              </Card>

              <Card className="border-border/50">
                <CardContent className="pt-6">
                  <div>
                    <p className="text-xs text-muted-foreground">ETA</p>
                    <p className="font-bold text-sm mt-1">2025-01-15</p>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-border/50">
                <CardContent className="pt-6">
                  <div>
                    <p className="text-xs text-muted-foreground">Kemajuan</p>
                    <p className="font-bold text-sm mt-1">65%</p>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Timeline */}
            <Card className="border-border/50">
              <CardHeader>
                <CardTitle>Timeline Pengiriman</CardTitle>
                <CardDescription>Urutan kejadian dan perubahan status</CardDescription>
              </CardHeader>
              <CardContent>
                <ShipmentTimeline shipmentId={shipmentId} isExport={isExport} />
              </CardContent>
            </Card>

            {/* Vessel Info */}
            <Card className="border-border/50">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Ship className="w-5 h-5" />
                  Informasi Kapal
                </CardTitle>
              </CardHeader>
              <CardContent className="grid md:grid-cols-2 gap-6">
                <div className="space-y-3">
                  <div>
                    <p className="text-xs text-muted-foreground">Nama Kapal</p>
                    <p className="font-semibold">Maersk Seatrade</p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">IMO Number</p>
                    <p className="font-semibold">9450132</p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Tipe Kapal</p>
                    <p className="font-semibold">Container Ship</p>
                  </div>
                </div>

                <div className="space-y-3">
                  <div>
                    <p className="text-xs text-muted-foreground">Kapasitas</p>
                    <p className="font-semibold">2000 TEU</p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Kecepatan</p>
                    <p className="font-semibold">18.5 knot</p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Flagged</p>
                    <p className="font-semibold">Denmark</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Shipment Details */}
            <Card className="border-border/50">
              <CardHeader>
                <CardTitle>Detail Pengiriman</CardTitle>
              </CardHeader>
              <CardContent className="grid md:grid-cols-2 gap-6">
                <div className="space-y-3">
                  <div>
                    <p className="text-xs text-muted-foreground">Pengirim/Importer</p>
                    <p className="font-semibold">PT. Supplier Indonesia</p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Penerima</p>
                    <p className="font-semibold">ABC Trading Company</p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Jenis Barang</p>
                    <p className="font-semibold">Elektronik (Kontainer)</p>
                  </div>
                </div>

                <div className="space-y-3">
                  <div>
                    <p className="text-xs text-muted-foreground">Jumlah</p>
                    <p className="font-semibold">100 Unit</p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Berat</p>
                    <p className="font-semibold">50 Ton</p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Container Number</p>
                    <p className="font-semibold font-mono">MAEU1234567</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Documents */}
            <Card className="border-border/50">
              <CardHeader>
                <CardTitle>Dokumen Pengiriman</CardTitle>
                <CardDescription>Download dokumen terkait pengiriman</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <Button variant="outline" className="w-full justify-start bg-transparent">
                    📄 Bill of Lading (B/L)
                  </Button>
                  <Button variant="outline" className="w-full justify-start bg-transparent">
                    📄 Commercial Invoice
                  </Button>
                  <Button variant="outline" className="w-full justify-start bg-transparent">
                    📄 Packing List
                  </Button>
                  <Button variant="outline" className="w-full justify-start bg-transparent">
                    📄 Certificate of Origin
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </main>
      </div>
    </div>
  )
}
