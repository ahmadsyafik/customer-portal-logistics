"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { DashboardNavbar } from "@/components/dashboard-navbar"
import { DashboardSidebar } from "@/components/dashboard-sidebar"
import { Search } from "lucide-react"

export default function TrackingPage() {
  const [searchId, setSearchId] = useState("")
  const [selectedShipment, setSelectedShipment] = useState<string | null>(null)

  return (
    <div className="min-h-screen bg-background">
      <DashboardNavbar />
      <div className="flex">
        <DashboardSidebar isOpen={true} setIsOpen={() => {}} />

        <main className="flex-1">
          <div className="p-6 md:p-8 space-y-8">
            {/* Header */}
            <div>
              <h1 className="text-3xl md:text-4xl font-bold">Tracking & Pelacakan Pengiriman</h1>
              <p className="text-muted-foreground">Monitor posisi kapal dan status pengiriman Anda secara real-time</p>
            </div>

            {/* Search Bar */}
            <Card className="border-border/50">
              <CardContent className="pt-6">
                <div className="flex gap-3">
                  <div className="flex-1 relative">
                    <Search className="absolute left-3 top-3 w-5 h-5 text-muted-foreground" />
                    <Input
                      placeholder="Cari nomor pengiriman (SHP-xxx atau IMP-xxx)"
                      value={searchId}
                      onChange={(e) => setSearchId(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                  <Button>Cari</Button>
                </div>
              </CardContent>
            </Card>

            {/* Tracking Result */}
            {!selectedShipment ? (
              <div className="grid md:grid-cols-2 gap-6">
                {[
                  { id: "SHP-001", type: "Export", status: "In Transit" },
                  { id: "IMP-001", type: "Import", status: "Customs Clearance" },
                ].map((ship) => (
                  <button key={ship.id} onClick={() => setSelectedShipment(ship.id)} className="text-left">
                    <Card className="border-border/50 hover:border-accent/50 hover:shadow-lg transition-all">
                      <CardHeader>
                        <div className="flex items-center justify-between">
                          <div>
                            <CardTitle>{ship.id}</CardTitle>
                            <CardDescription>{ship.type}</CardDescription>
                          </div>
                          <div
                            className={`px-3 py-1 rounded-full text-xs font-semibold ${
                              ship.status === "In Transit"
                                ? "bg-accent/10 text-accent"
                                : "bg-secondary/10 text-secondary"
                            }`}
                          >
                            {ship.status}
                          </div>
                        </div>
                      </CardHeader>
                    </Card>
                  </button>
                ))}
              </div>
            ) : (
              <button onClick={() => setSelectedShipment(null)} className="text-accent hover:underline text-sm">
                ← Kembali ke Daftar
              </button>
            )}

            {/* Detailed Tracking */}
            {selectedShipment && (
              <>
                {selectedShipment.startsWith("SHP") ? (
                  <div className="space-y-6">
                    <Card className="border-border/50">
                      <CardHeader>
                        <CardTitle>Detail Pengiriman Ekspor {selectedShipment}</CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-6">
                        {/* Timeline */}
                        <div className="space-y-4">
                          <h3 className="font-semibold">Status Pengiriman</h3>
                          <div className="space-y-4">
                            {[
                              { status: "Pemesanan Diterima", date: "2025-01-01", time: "10:30", completed: true },
                              { status: "Dokumen Tervalidasi", date: "2025-01-02", time: "14:15", completed: true },
                              { status: "Kapal Berangkat", date: "2025-01-03", time: "08:00", completed: true },
                              {
                                status: "Pengiriman Dalam Perjalanan",
                                date: "2025-01-04 - 2025-01-15",
                                time: "Ongoing",
                                completed: true,
                              },
                              { status: "Tiba di Tujuan (Est.)", date: "2025-01-15", time: "08:00", completed: false },
                            ].map((step, idx) => (
                              <div key={idx} className="flex gap-4">
                                <div className="flex flex-col items-center">
                                  <div
                                    className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold ${
                                      step.completed ? "bg-accent text-white" : "bg-muted text-muted-foreground"
                                    }`}
                                  >
                                    {step.completed ? "✓" : idx + 1}
                                  </div>
                                  {idx < 4 && (
                                    <div className={`w-1 h-12 ${step.completed ? "bg-accent" : "bg-muted"}`}></div>
                                  )}
                                </div>
                                <div>
                                  <p className="font-semibold">{step.status}</p>
                                  <p className="text-sm text-muted-foreground">{step.date}</p>
                                  <p className="text-xs text-muted-foreground">{step.time}</p>
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>

                        {/* Current Location */}
                        <div className="bg-accent/5 border border-accent/20 rounded-lg p-4">
                          <p className="text-sm font-semibold mb-2">Lokasi Kapal Saat Ini</p>
                          <p className="text-sm">Selat Malaka, Singapura - 2°N, 103°E</p>
                          <p className="text-xs text-muted-foreground mt-2">Kecepatan: 18.5 knot | Cuaca: Cerah</p>
                        </div>

                        {/* Shipment Details */}
                        <div className="grid md:grid-cols-2 gap-4 bg-muted/30 rounded-lg p-4">
                          <div>
                            <p className="text-xs text-muted-foreground">Kapal</p>
                            <p className="font-semibold">Maersk Seatrade</p>
                          </div>
                          <div>
                            <p className="text-xs text-muted-foreground">ETA</p>
                            <p className="font-semibold">2025-01-15 08:00</p>
                          </div>
                          <div>
                            <p className="text-xs text-muted-foreground">Jenis Barang</p>
                            <p className="font-semibold">Elektronik (Kontainer)</p>
                          </div>
                          <div>
                            <p className="text-xs text-muted-foreground">Berat</p>
                            <p className="font-semibold">50 Ton</p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                ) : (
                  <div className="space-y-6">
                    <Card className="border-border/50">
                      <CardHeader>
                        <CardTitle>Detail Pengiriman Impor {selectedShipment}</CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-6">
                        {/* Timeline */}
                        <div className="space-y-4">
                          <h3 className="font-semibold">Status Pengiriman</h3>
                          <div className="space-y-4">
                            {[
                              { status: "Permintaan Diterima", date: "2025-01-01", time: "10:30", completed: true },
                              { status: "Dokumen Terverifikasi", date: "2025-01-02", time: "14:15", completed: true },
                              {
                                status: "Kapal Dalam Perjalanan",
                                date: "2025-01-03 - 2025-01-18",
                                time: "Ongoing",
                                completed: true,
                              },
                              {
                                status: "Kapal Tiba di Pelabuhan",
                                date: "2025-01-18",
                                time: "06:00",
                                completed: false,
                              },
                              {
                                status: "Proses Bongkar Muat",
                                date: "2025-01-18 - 2025-01-19",
                                time: "Pending",
                                completed: false,
                              },
                              { status: "Bea Cukai Clearance", date: "2025-01-19", time: "Pending", completed: false },
                            ].map((step, idx) => (
                              <div key={idx} className="flex gap-4">
                                <div className="flex flex-col items-center">
                                  <div
                                    className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold ${
                                      step.completed ? "bg-secondary text-white" : "bg-muted text-muted-foreground"
                                    }`}
                                  >
                                    {step.completed ? "✓" : idx + 1}
                                  </div>
                                  {idx < 5 && (
                                    <div className={`w-1 h-12 ${step.completed ? "bg-secondary" : "bg-muted"}`}></div>
                                  )}
                                </div>
                                <div>
                                  <p className="font-semibold">{step.status}</p>
                                  <p className="text-sm text-muted-foreground">{step.date}</p>
                                  <p className="text-xs text-muted-foreground">{step.time}</p>
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>

                        {/* Shipment Details */}
                        <div className="grid md:grid-cols-2 gap-4 bg-muted/30 rounded-lg p-4">
                          <div>
                            <p className="text-xs text-muted-foreground">Kapal</p>
                            <p className="font-semibold">Ever Given</p>
                          </div>
                          <div>
                            <p className="text-xs text-muted-foreground">ETA</p>
                            <p className="font-semibold">2025-01-18 06:00</p>
                          </div>
                          <div>
                            <p className="text-xs text-muted-foreground">Jenis Barang</p>
                            <p className="font-semibold">Mesin & Spare Parts</p>
                          </div>
                          <div>
                            <p className="text-xs text-muted-foreground">Berat</p>
                            <p className="font-semibold">75 Ton</p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                )}
              </>
            )}
          </div>
        </main>
      </div>
    </div>
  )
}
