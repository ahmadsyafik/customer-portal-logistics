"use client"

import { useState } from "react"
import { DashboardNavbar } from "@/components/dashboard-navbar"
import { DashboardSidebar } from "@/components/dashboard-sidebar"
import { ExportStepper } from "@/components/export-stepper"
import { ExportOrderingForm } from "@/components/export-forms/ordering-form"
import { ExportValidatingForm } from "@/components/export-forms/validating-form"
import { ExportPlanningForm } from "@/components/export-forms/planning-form"

export default function ExportPage() {
  const [currentStep, setCurrentStep] = useState<"ordering" | "validating" | "planning">("ordering")
  const [formData, setFormData] = useState({
    shipper: "",
    shipperEmail: "",
    shipperPhone: "",
    consignee: "",
    destination: "",
    goodsType: "",
    quantity: "",
    weight: "",
    containerType: "",
    services: [] as string[],
    documents: null as File | null,
    documentStatus: "pending" as "pending" | "approved" | "rejected",
    advancePayment: "",
    vesselName: "",
    eta: "",
    truckBookingTime: "",
  })

  const handleStepChange = (step: "ordering" | "validating" | "planning") => {
    setCurrentStep(step)
  }

  const handleFormUpdate = (data: Partial<typeof formData>) => {
    setFormData((prev) => ({ ...prev, ...data }))
  }

  return (
    <div className="min-h-screen bg-background">
      <DashboardNavbar />
      <div className="flex">
        <DashboardSidebar isOpen={true} setIsOpen={() => {}} />

        <main className="flex-1">
          <div className="p-6 md:p-8 space-y-8">
            {/* Header */}
            <div>
              <h1 className="text-3xl md:text-4xl font-bold">Proses Ekspor Barang</h1>
              <p className="text-muted-foreground">Kelola ekspor barang Anda melalui tiga tahap terstruktur</p>
            </div>

            {/* Stepper */}
            <ExportStepper currentStep={currentStep} />

            {/* Form Content */}
            <div className="max-w-4xl">
              {currentStep === "ordering" && (
                <ExportOrderingForm
                  data={formData}
                  onUpdate={handleFormUpdate}
                  onNext={() => handleStepChange("validating")}
                />
              )}

              {currentStep === "validating" && (
                <ExportValidatingForm
                  data={formData}
                  onUpdate={handleFormUpdate}
                  onNext={() => handleStepChange("planning")}
                  onBack={() => handleStepChange("ordering")}
                />
              )}

              {currentStep === "planning" && (
                <ExportPlanningForm
                  data={formData}
                  onUpdate={handleFormUpdate}
                  onBack={() => handleStepChange("validating")}
                />
              )}
            </div>
          </div>
        </main>
      </div>
    </div>
  )
}
