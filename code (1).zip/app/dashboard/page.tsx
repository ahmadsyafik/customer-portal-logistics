"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { DashboardNavbar } from "@/components/dashboard-navbar"
import { DashboardSidebar } from "@/components/dashboard-sidebar"
import { ShipmentChart } from "@/components/shipment-chart"
import { ShipmentList } from "@/components/shipment-list"
import { NotificationCenter } from "@/components/notification-center"
import { Plus, Activity, TrendingUp, AlertCircle } from "lucide-react"

export default function DashboardPage() {
  const [sidebarOpen, setSidebarOpen] = useState(true)
  const [shipments, setShipments] = useState([
    {
      id: "SHP-001",
      type: "Ekspor",
      status: "In Transit",
      destination: "Singapore",
      progress: 65,
      vesselName: "Maersk Seatrade",
      eta: "2025-01-15",
      cargo: "Kontainer Elektronik",
    },
    {
      id: "SHP-002",
      type: "Impor",
      status: "Customs",
      destination: "Jakarta",
      progress: 45,
      vesselName: "Ever Given",
      eta: "2025-01-18",
      cargo: "Raw Materials",
    },
    {
      id: "SHP-003",
      type: "Ekspor",
      status: "Delivered",
      destination: "Rotterdam",
      progress: 100,
      vesselName: "MSC Gulsun",
      eta: "2024-12-20",
      cargo: "Palm Oil",
    },
    {
      id: "SHP-004",
      type: "Impor",
      status: "Loading",
      destination: "Surabaya",
      progress: 25,
      vesselName: "ONE Apus",
      eta: "2025-01-10",
      cargo: "Industrial Equipment",
    },
  ])

  const [notificationVisible, setNotificationVisible] = useState(true)

  const stats = [
    {
      title: "Total Pengiriman",
      value: "1,234",
      description: "Bulan ini",
      icon: Activity,
      color: "text-accent",
    },
    {
      title: "Pengiriman Aktif",
      value: "45",
      description: "Sedang berlangsung",
      icon: TrendingUp,
      color: "text-secondary",
    },
    {
      title: "On-Time Rate",
      value: "98.5%",
      description: "Pengiriman tepat waktu",
      icon: Activity,
      color: "text-accent",
    },
    {
      title: "Alert Aktif",
      value: "3",
      description: "Memerlukan perhatian",
      icon: AlertCircle,
      color: "text-destructive",
    },
  ]

  return (
    <div className="min-h-screen bg-background">
      <DashboardNavbar />
      <div className="flex">
        <DashboardSidebar isOpen={sidebarOpen} setIsOpen={setSidebarOpen} />

        <main className={`flex-1 transition-all duration-300 ${sidebarOpen ? "ml-0" : "ml-0"}`}>
          <div className="p-6 md:p-8 space-y-8">
            {/* Header */}
            <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
              <div>
                <h1 className="text-3xl md:text-4xl font-bold">Dashboard Logistik</h1>
                <p className="text-muted-foreground">Pantau semua pengiriman Anda secara real-time</p>
              </div>
              <div className="flex gap-3">
                <Link href="/dashboard/export">
                  <Button className="gap-2">
                    <Plus className="w-4 h-4" />
                    Ekspor Baru
                  </Button>
                </Link>
                <Link href="/dashboard/import">
                  <Button variant="outline" className="gap-2 bg-transparent">
                    <Plus className="w-4 h-4" />
                    Impor Baru
                  </Button>
                </Link>
              </div>
            </div>

            {/* Notification */}
            {notificationVisible && <NotificationCenter onClose={() => setNotificationVisible(false)} />}

            {/* Stats Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {stats.map((stat, idx) => {
                const Icon = stat.icon
                return (
                  <Card key={idx} className="border-border/50">
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                      <CardTitle className="text-sm font-medium">{stat.title}</CardTitle>
                      <Icon className={`w-4 h-4 ${stat.color}`} />
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">{stat.value}</div>
                      <p className="text-xs text-muted-foreground">{stat.description}</p>
                    </CardContent>
                  </Card>
                )
              })}
            </div>

            {/* Charts and Shipments */}
            <div className="grid lg:grid-cols-3 gap-6">
              <Card className="lg:col-span-2 border-border/50">
                <CardHeader>
                  <CardTitle>Statistik Pengiriman 30 Hari Terakhir</CardTitle>
                  <CardDescription>Performa pengiriman ekspor vs impor</CardDescription>
                </CardHeader>
                <CardContent>
                  <ShipmentChart />
                </CardContent>
              </Card>

              <Card className="border-border/50">
                <CardHeader>
                  <CardTitle className="text-lg">Ringkasan Status</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-3 h-3 rounded-full bg-accent"></div>
                      <span className="text-sm">In Transit</span>
                    </div>
                    <span className="font-semibold">12</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-3 h-3 rounded-full bg-secondary"></div>
                      <span className="text-sm">Customs</span>
                    </div>
                    <span className="font-semibold">8</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-3 h-3 rounded-full bg-accent/50"></div>
                      <span className="text-sm">Loading</span>
                    </div>
                    <span className="font-semibold">5</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-3 h-3 rounded-full bg-green-500"></div>
                      <span className="text-sm">Delivered</span>
                    </div>
                    <span className="font-semibold">20</span>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Shipments List */}
            <Card className="border-border/50">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>Pengiriman Terkini</CardTitle>
                    <CardDescription>Daftar lengkap semua pengiriman aktif</CardDescription>
                  </div>
                  <Link href="/dashboard/shipments">
                    <Button variant="outline" size="sm">
                      Lihat Semua
                    </Button>
                  </Link>
                </div>
              </CardHeader>
              <CardContent>
                <ShipmentList shipments={shipments} />
              </CardContent>
            </Card>
          </div>
        </main>
      </div>
    </div>
  )
}
