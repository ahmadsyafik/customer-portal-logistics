"use client"

import { useState } from "react"
import { DashboardNavbar } from "@/components/dashboard-navbar"
import { DashboardSidebar } from "@/components/dashboard-sidebar"
import { NusantaraStepper } from "@/components/nusantara-stepper"
import { NusantaraOrderingForm } from "@/components/nusantara-forms/ordering-form"
import { NusantaraValidatingForm } from "@/components/nusantara-forms/validating-form"
import { NusantaraPlanningForm } from "@/components/nusantara-forms/planning-form"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Plus, MapPin, CheckCircle, Truck, AlertCircle } from "lucide-react"
import Link from "next/link"

export default function NusantaraPage() {
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [showForm, setShowForm] = useState(false)
  const [currentStep, setCurrentStep] = useState<"ordering" | "validating" | "planning">("ordering")
  const [formData, setFormData] = useState({
    sender: "",
    senderEmail: "",
    senderPhone: "",
    recipient: "",
    origin: "",
    destination: "",
    goodsType: "",
    quantity: "",
    weight: "",
    serviceType: "",
    advancePayment: "",
    documentStatus: "pending" as "pending" | "approved" | "rejected",
    deliverySchedule: "",
    pickupTime: "",
    insuranceRequested: false,
  })

  const [shipments, setShipments] = useState([
    {
      id: "NUS001",
      sender: "PT Maju Jaya",
      origin: "Jakarta",
      destination: "Surabaya",
      distance: "750 km",
      duration: "3-4 hari",
      status: "Delivered",
      cost: "Rp 5.000.000",
      date: "2024-10-28",
      trackingNumber: "NUS-2024-001",
    },
    {
      id: "NUS002",
      sender: "CV Bintang Utama",
      origin: "Bandung",
      destination: "Medan",
      distance: "1.250 km",
      duration: "5-6 hari",
      status: "In Transit",
      cost: "Rp 7.500.000",
      date: "2024-10-25",
      trackingNumber: "NUS-2024-002",
    },
    {
      id: "NUS003",
      sender: "UD Sejahtera",
      origin: "Surabaya",
      destination: "Bali",
      distance: "350 km",
      duration: "1-2 hari",
      status: "Pending",
      cost: "Rp 3.000.000",
      date: "2024-10-20",
      trackingNumber: "NUS-2024-003",
    },
  ])

  const handleStepChange = (step: "ordering" | "validating" | "planning") => {
    setCurrentStep(step)
  }

  const handleFormUpdate = (data: Partial<typeof formData>) => {
    setFormData((prev) => ({ ...prev, ...data }))
  }

  const handleFormSubmit = () => {
    const newShipment = {
      id: `NUS${String(shipments.length + 1).padStart(3, "0")}`,
      sender: formData.sender,
      origin: formData.origin,
      destination: formData.destination,
      distance: `${Math.floor(Math.random() * 2000) + 300} km`,
      duration: `${Math.floor(Math.random() * 5) + 2}-${Math.floor(Math.random() * 5) + 4} hari`,
      status: "Pending",
      cost: `Rp ${(Math.floor(Math.random() * 8) + 2) * 1000000}`,
      date: new Date().toISOString().split("T")[0],
      trackingNumber: `NUS-2024-${String(shipments.length + 1).padStart(3, "0")}`,
    }

    setShipments((prev) => [newShipment, ...prev])
    setFormData({
      sender: "",
      senderEmail: "",
      senderPhone: "",
      recipient: "",
      origin: "",
      destination: "",
      goodsType: "",
      quantity: "",
      weight: "",
      serviceType: "",
      advancePayment: "",
      documentStatus: "pending",
      deliverySchedule: "",
      pickupTime: "",
      insuranceRequested: false,
    })
    setShowForm(false)
    setCurrentStep("ordering")
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "Delivered":
        return "bg-green-500/20 text-green-700"
      case "In Transit":
        return "bg-blue-500/20 text-blue-700"
      case "Pending":
        return "bg-yellow-500/20 text-yellow-700"
      default:
        return "bg-gray-500/20 text-gray-700"
    }
  }

  const getStatusIcon = (status: string) => {
    if (status === "Delivered") return <CheckCircle className="w-4 h-4" />
    if (status === "In Transit") return <Truck className="w-4 h-4" />
    return <AlertCircle className="w-4 h-4" />
  }

  return (
    <div className="min-h-screen bg-background">
      <DashboardNavbar />
      <div className="flex">
        <DashboardSidebar isOpen={sidebarOpen} setIsOpen={setSidebarOpen} />

        <main className="flex-1">
          <div className="p-6 md:p-8 space-y-8">
            {/* Header */}
            <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
              <div>
                <h1 className="text-3xl md:text-4xl font-bold">Logistik Nusantara</h1>
                <p className="text-muted-foreground">Layanan logistik domestik untuk seluruh wilayah Indonesia</p>
              </div>
              <Button onClick={() => setShowForm(!showForm)} className="gap-2">
                <Plus className="w-4 h-4" />
                Pengiriman Baru
              </Button>
            </div>

            {/* Form Section */}
            {showForm && (
              <div className="space-y-6">
                <NusantaraStepper currentStep={currentStep} />

                <div className="max-w-4xl">
                  {currentStep === "ordering" && (
                    <NusantaraOrderingForm
                      data={formData}
                      onUpdate={handleFormUpdate}
                      onNext={() => handleStepChange("validating")}
                      onCancel={() => {
                        setShowForm(false)
                        setCurrentStep("ordering")
                      }}
                    />
                  )}

                  {currentStep === "validating" && (
                    <NusantaraValidatingForm
                      data={formData}
                      onUpdate={handleFormUpdate}
                      onNext={() => handleStepChange("planning")}
                      onBack={() => handleStepChange("ordering")}
                    />
                  )}

                  {currentStep === "planning" && (
                    <NusantaraPlanningForm
                      data={formData}
                      onUpdate={handleFormUpdate}
                      onBack={() => handleStepChange("validating")}
                      onSubmit={handleFormSubmit}
                    />
                  )}
                </div>
              </div>
            )}

            {/* Shipments List */}
            {!showForm && (
              <div className="space-y-4">
                <h2 className="text-xl font-semibold">Daftar Pengiriman Domestik</h2>
                <div className="grid gap-4">
                  {shipments.map((shipment) => (
                    <Card key={shipment.id} className="border-border/50 hover:border-accent/50 transition-colors">
                      <CardContent className="pt-6">
                        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                          <div className="flex-1 space-y-2">
                            <div className="flex items-center gap-2">
                              <p className="font-semibold text-lg">{shipment.id}</p>
                              <span
                                className={`px-2 py-1 rounded-full text-xs font-semibold flex items-center gap-1 ${getStatusColor(shipment.status)}`}
                              >
                                {getStatusIcon(shipment.status)}
                                {shipment.status}
                              </span>
                            </div>
                            <div className="flex items-center gap-2 text-muted-foreground">
                              <MapPin className="w-4 h-4" />
                              <span>
                                {shipment.origin} → {shipment.destination}
                              </span>
                            </div>
                            <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-sm">
                              <div>
                                <p className="text-muted-foreground">Jarak</p>
                                <p className="font-semibold">{shipment.distance}</p>
                              </div>
                              <div>
                                <p className="text-muted-foreground">Durasi</p>
                                <p className="font-semibold">{shipment.duration}</p>
                              </div>
                              <div>
                                <p className="text-muted-foreground">Biaya</p>
                                <p className="font-semibold text-accent">{shipment.cost}</p>
                              </div>
                              <div>
                                <p className="text-muted-foreground">Tanggal</p>
                                <p className="font-semibold">{shipment.date}</p>
                              </div>
                            </div>
                          </div>
                          <Link
                            href={`/dashboard/nusantara/tracking/${shipment.trackingNumber}`}
                            className="w-full md:w-auto"
                          >
                            <Button variant="outline" className="w-full bg-transparent">
                              Lihat Detail & Tracking
                            </Button>
                          </Link>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            )}
          </div>
        </main>
      </div>
    </div>
  )
}
