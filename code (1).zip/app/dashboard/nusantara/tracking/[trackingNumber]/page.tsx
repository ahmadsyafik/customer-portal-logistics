"use client"

import { DashboardNavbar } from "@/components/dashboard-navbar"
import { DashboardSidebar } from "@/components/dashboard-sidebar"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ArrowLeft, MapPin, Truck, CheckCircle, Clock, Phone, Mail } from "lucide-react"
import Link from "next/link"
import { useState } from "react"

interface TrackingPageProps {
  params: {
    trackingNumber: string
  }
}

export default function TrackingPage({ params }: TrackingPageProps) {
  const [sidebarOpen, setSidebarOpen] = useState(false)

  // Mock data berdasarkan tracking number
  const trackingData = {
    "NUS-2024-001": {
      id: "NUS001",
      trackingNumber: "NUS-2024-001",
      sender: "PT Maju Jaya",
      recipient: "CV Sejahtera",
      origin: "Jakarta",
      destination: "Surabaya",
      status: "Delivered",
      date: "2024-10-28",
      cost: "Rp 5.000.000",
      goodsType: "Electronics",
      weight: 150,
      quantity: 50,
      serviceType: "Express (2-3 hari)",
      senderPhone: "+62-21-5555-5555",
      senderEmail: "contact@majujaya.com",
      recipientPhone: "+62-31-6666-6666",
      timeline: [
        { date: "2024-10-25 08:00", status: "Order Created", description: "Pesanan dibuat dan dikonfirmasi" },
        { date: "2024-10-25 10:30", status: "Picked Up", description: "Barang diambil dari lokasi pengirim" },
        { date: "2024-10-25 14:00", status: "In Transit", description: "Barang dalam perjalanan ke Surabaya" },
        { date: "2024-10-26 06:00", status: "Transit Hub", description: "Barang sampai di hub transit Surabaya" },
        { date: "2024-10-26 14:00", status: "Out for Delivery", description: "Barang dalam perjalanan ke penerima" },
        { date: "2024-10-28 10:30", status: "Delivered", description: "Barang berhasil diterima oleh penerima" },
      ],
    },
    "NUS-2024-002": {
      id: "NUS002",
      trackingNumber: "NUS-2024-002",
      sender: "CV Bintang Utama",
      recipient: "PT Modern Distribusi",
      origin: "Bandung",
      destination: "Medan",
      status: "In Transit",
      date: "2024-10-25",
      cost: "Rp 7.500.000",
      goodsType: "General Cargo",
      weight: 200,
      quantity: 80,
      serviceType: "Regular (5-6 hari)",
      senderPhone: "+62-22-7777-7777",
      senderEmail: "info@bintangutama.com",
      recipientPhone: "+62-61-8888-8888",
      timeline: [
        { date: "2024-10-25 09:00", status: "Order Created", description: "Pesanan dibuat dan dikonfirmasi" },
        { date: "2024-10-25 11:00", status: "Picked Up", description: "Barang diambil dari lokasi pengirim" },
        { date: "2024-10-25 16:00", status: "In Transit", description: "Barang dalam perjalanan ke Medan" },
        { date: "2024-10-26 10:00", status: "Transit Hub", description: "Barang sampai di hub transit Surabaya" },
        { date: "2024-10-27 08:00", status: "In Transit", description: "Barang melanjutkan perjalanan ke Medan" },
      ],
    },
    "NUS-2024-003": {
      id: "NUS003",
      trackingNumber: "NUS-2024-003",
      sender: "UD Sejahtera",
      recipient: "Toko Bahagia",
      origin: "Surabaya",
      destination: "Bali",
      status: "Pending",
      date: "2024-10-20",
      cost: "Rp 3.000.000",
      goodsType: "Furniture",
      weight: 100,
      quantity: 20,
      serviceType: "Overnight",
      senderPhone: "+62-31-9999-9999",
      senderEmail: "cs@sejahtera.com",
      recipientPhone: "+62-361-1111-1111",
      timeline: [
        { date: "2024-10-20 14:00", status: "Order Created", description: "Pesanan dibuat dan dikonfirmasi" },
        { date: "2024-10-21 09:00", status: "Waiting Pickup", description: "Menunggu jadwal penjemputan barang" },
      ],
    },
  }

  const data = trackingData[params.trackingNumber as keyof typeof trackingData] || trackingData["NUS-2024-001"]

  const getStatusColor = (status: string) => {
    if (status === "Delivered") return "bg-green-500/20 text-green-700"
    if (status === "In Transit") return "bg-blue-500/20 text-blue-700"
    if (status === "Pending" || status === "Waiting Pickup") return "bg-yellow-500/20 text-yellow-700"
    return "bg-gray-500/20 text-gray-700"
  }

  const getTimelineIcon = (status: string) => {
    if (status === "Delivered") return <CheckCircle className="w-6 h-6 text-green-600" />
    if (status.includes("Transit") || status.includes("In")) return <Truck className="w-6 h-6 text-blue-600" />
    return <Clock className="w-6 h-6 text-gray-600" />
  }

  return (
    <div className="min-h-screen bg-background">
      <DashboardNavbar />
      <div className="flex">
        <DashboardSidebar isOpen={sidebarOpen} setIsOpen={setSidebarOpen} />

        <main className="flex-1">
          <div className="p-6 md:p-8 space-y-8">
            {/* Header */}
            <Link href="/dashboard/nusantara">
              <Button variant="ghost" className="gap-2 mb-4">
                <ArrowLeft className="w-4 h-4" />
                Kembali ke Daftar Pengiriman
              </Button>
            </Link>

            <div>
              <h1 className="text-3xl md:text-4xl font-bold">Tracking Pengiriman</h1>
              <p className="text-muted-foreground">Rincian dan pelacakan pengiriman Anda</p>
            </div>

            {/* Main Status Card */}
            <Card className="border-border/50">
              <CardHeader>
                <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                  <div>
                    <CardTitle className="text-2xl">{data.trackingNumber}</CardTitle>
                    <CardDescription className="mt-2">
                      Status:{" "}
                      <span
                        className={`inline-block px-3 py-1 rounded-full text-sm font-semibold ${getStatusColor(data.status)}`}
                      >
                        {data.status}
                      </span>
                    </CardDescription>
                  </div>
                  <div className="flex gap-2">
                    <Button variant="outline">Download Invoice</Button>
                    <Button>Print Tracking</Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Route */}
                <div className="space-y-4">
                  <h3 className="font-semibold">Rute Pengiriman</h3>
                  <div className="flex flex-col md:flex-row md:items-center gap-4">
                    <div className="flex-1">
                      <p className="text-sm text-muted-foreground">Dari</p>
                      <p className="font-semibold">{data.origin}</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <MapPin className="w-5 h-5 text-secondary" />
                      <Truck className="w-5 h-5 text-secondary" />
                    </div>
                    <div className="flex-1">
                      <p className="text-sm text-muted-foreground">Ke</p>
                      <p className="font-semibold">{data.destination}</p>
                    </div>
                  </div>
                </div>

                {/* Details Grid */}
                <div className="grid md:grid-cols-3 gap-4 bg-muted/30 rounded-lg p-4">
                  <div>
                    <p className="text-sm text-muted-foreground">Jenis Barang</p>
                    <p className="font-semibold">{data.goodsType}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Berat</p>
                    <p className="font-semibold">{data.weight} kg</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Jumlah</p>
                    <p className="font-semibold">{data.quantity} unit</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Layanan</p>
                    <p className="font-semibold">{data.serviceType}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Tanggal</p>
                    <p className="font-semibold">{data.date}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Biaya</p>
                    <p className="font-semibold text-accent">{data.cost}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Sender & Recipient Info */}
            <div className="grid md:grid-cols-2 gap-6">
              <Card className="border-border/50">
                <CardHeader>
                  <CardTitle className="text-lg">Informasi Pengirim</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <p className="text-sm text-muted-foreground">Nama</p>
                    <p className="font-semibold">{data.sender}</p>
                  </div>
                  <div className="flex items-center gap-3">
                    <Phone className="w-4 h-4 text-muted-foreground" />
                    <a href={`tel:${data.senderPhone}`} className="text-sm font-medium text-secondary hover:underline">
                      {data.senderPhone}
                    </a>
                  </div>
                  <div className="flex items-center gap-3">
                    <Mail className="w-4 h-4 text-muted-foreground" />
                    <a
                      href={`mailto:${data.senderEmail}`}
                      className="text-sm font-medium text-secondary hover:underline"
                    >
                      {data.senderEmail}
                    </a>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-border/50">
                <CardHeader>
                  <CardTitle className="text-lg">Informasi Penerima</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <p className="text-sm text-muted-foreground">Nama</p>
                    <p className="font-semibold">{data.recipient}</p>
                  </div>
                  <div className="flex items-center gap-3">
                    <Phone className="w-4 h-4 text-muted-foreground" />
                    <a
                      href={`tel:${data.recipientPhone}`}
                      className="text-sm font-medium text-secondary hover:underline"
                    >
                      {data.recipientPhone}
                    </a>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Timeline */}
            <Card className="border-border/50">
              <CardHeader>
                <CardTitle className="text-lg">Status Pengiriman</CardTitle>
                <CardDescription>Riwayat lengkap pengiriman Anda</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {data.timeline.map((event, index) => (
                    <div key={index} className="flex gap-4">
                      <div className="flex flex-col items-center">
                        {getTimelineIcon(event.status)}
                        {index < data.timeline.length - 1 && <div className="w-1 h-12 bg-border mt-4"></div>}
                      </div>
                      <div className="pb-6">
                        <p className="font-semibold">{event.status}</p>
                        <p className="text-sm text-muted-foreground">{event.description}</p>
                        <p className="text-xs text-muted-foreground mt-2">{event.date}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </main>
      </div>
    </div>
  )
}
