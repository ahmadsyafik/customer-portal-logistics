"use client"

import Link from "next/link"
import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { CheckCircle2, Anchor, TrendingUp, Shield, Zap, Globe, Lock, BarChart3 } from "lucide-react"

export default function FeaturesPage() {
  const features = [
    {
      icon: Anchor,
      title: "Manajemen Ekspor-Impor Terintegrasi",
      description: "Kelola seluruh proses ekspor dan impor dalam satu platform terpusat",
    },
    {
      icon: Zap,
      title: "Tracking Real-time",
      description: "Monitor posisi kapal dan status pengiriman setiap saat dengan presisi tinggi",
    },
    {
      icon: BarChart3,
      title: "Laporan & Analitik",
      description: "Dapatkan insight mendalam tentang performa operasional dan efisiensi logistik Anda",
    },
    {
      icon: Shield,
      title: "Keamanan Data",
      description: "Perlindungan tingkat enterprise untuk semua transaksi dan dokumen Anda",
    },
    {
      icon: Globe,
      title: "Jangkauan Global",
      description: "Layanan logistik domestik, regional, dan internasional dalam satu platform",
    },
    {
      icon: Lock,
      title: "Manajemen Pembayaran",
      description: "Sistem pembayaran terkonsolidasi dengan laporan otomatis dan transparan",
    },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-muted/20">
      <Navbar />

      {/* Header */}
      <section className="pt-20 pb-12 px-4 md:px-6">
        <div className="max-w-7xl mx-auto text-center space-y-4">
          <h1 className="text-5xl md:text-6xl font-bold text-balance">Fitur-Fitur Unggulan</h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Semua yang Anda butuhkan untuk mengelola logistik maritim dengan efisien
          </p>
        </div>
      </section>

      {/* Features Grid */}
      <section className="py-16 px-4 md:px-6">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, idx) => {
              const Icon = feature.icon
              return (
                <Card key={idx} className="border-border/50 hover:border-accent/50 transition-colors">
                  <CardHeader>
                    <div className="w-12 h-12 rounded-lg bg-accent/10 flex items-center justify-center mb-4">
                      <Icon className="w-6 h-6 text-accent" />
                    </div>
                    <CardTitle>{feature.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground">{feature.description}</p>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        </div>
      </section>

      {/* Detailed Features */}
      <section className="py-20 px-4 md:px-6 bg-card/50">
        <div className="max-w-7xl mx-auto space-y-16">
          <div className="grid md:grid-cols-2 gap-8 items-center">
            <div className="space-y-4">
              <h2 className="text-3xl font-bold">Manajemen Pengiriman Komprehensif</h2>
              <p className="text-muted-foreground">
                Dari perencanaan hingga pengiriman, kelola setiap aspek operasional dengan tools yang dirancang khusus
                untuk logistik maritim.
              </p>
              <ul className="space-y-2">
                {[
                  "Pemesanan dan validasi dokumen otomatis",
                  "Penjadwalan kapal yang dioptimalkan",
                  "Tracking muatan real-time",
                ].map((item, idx) => (
                  <li key={idx} className="flex items-center gap-2 text-sm">
                    <CheckCircle2 className="w-4 h-4 text-green-600" />
                    {item}
                  </li>
                ))}
              </ul>
            </div>
            <Card className="border-border/50">
              <CardContent className="pt-6">
                <div className="aspect-video bg-muted rounded-lg flex items-center justify-center">
                  <TrendingUp className="w-12 h-12 text-muted-foreground/50" />
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="grid md:grid-cols-2 gap-8 items-center">
            <Card className="border-border/50 md:order-2">
              <CardContent className="pt-6">
                <div className="aspect-video bg-muted rounded-lg flex items-center justify-center">
                  <Shield className="w-12 h-12 text-muted-foreground/50" />
                </div>
              </CardContent>
            </Card>
            <div className="space-y-4 md:order-1">
              <h2 className="text-3xl font-bold">Keamanan Terjamin</h2>
              <p className="text-muted-foreground">
                Data Anda dilindungi dengan enkripsi tingkat enterprise dan compliance penuh terhadap regulasi
                internasional.
              </p>
              <ul className="space-y-2">
                {[
                  "Enkripsi end-to-end untuk semua data",
                  "Compliance dengan standar internasional",
                  "Backup otomatis dan disaster recovery",
                ].map((item, idx) => (
                  <li key={idx} className="flex items-center gap-2 text-sm">
                    <CheckCircle2 className="w-4 h-4 text-green-600" />
                    {item}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 px-4 md:px-6">
        <div className="max-w-4xl mx-auto text-center space-y-8 bg-gradient-to-r from-primary to-primary/80 rounded-2xl p-12 text-white">
          <h2 className="text-4xl font-bold">Siap Mengoptimalkan Logistik Anda?</h2>
          <Link href="/auth/signup">
            <Button size="lg" variant="secondary">
              Mulai Sekarang
            </Button>
          </Link>
        </div>
      </section>

      <Footer />
    </div>
  )
}
