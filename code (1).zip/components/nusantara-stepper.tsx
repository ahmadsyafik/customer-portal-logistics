"use client"

import { Check } from "lucide-react"

interface NusantaraStepperProps {
  currentStep: "ordering" | "validating" | "planning"
}

export function NusantaraStepper({ currentStep }: NusantaraStepperProps) {
  const steps = [
    { id: "ordering", label: "Pemesanan", description: "Data pengiriman" },
    { id: "validating", label: "Validasi", description: "Validasi pembayaran" },
    { id: "planning", label: "Penjadwalan", description: "Jadwal pengiriman" },
  ] as const

  const getStepIndex = (step: typeof currentStep) => {
    return steps.findIndex((s) => s.id === step)
  }

  const currentIndex = getStepIndex(currentStep)

  return (
    <div className="flex items-center justify-between">
      {steps.map((step, index) => (
        <div key={step.id} className="flex items-center flex-1">
          <div className="flex flex-col items-center">
            <div
              className={`w-12 h-12 rounded-full flex items-center justify-center font-semibold transition-all ${
                index < currentIndex
                  ? "bg-secondary text-white"
                  : index === currentIndex
                    ? "bg-secondary/20 text-secondary ring-2 ring-secondary"
                    : "bg-muted text-muted-foreground"
              }`}
            >
              {index < currentIndex ? <Check className="w-6 h-6" /> : index + 1}
            </div>
            <div className="mt-3 text-center">
              <p className="font-semibold text-sm">{step.label}</p>
              <p className="text-xs text-muted-foreground">{step.description}</p>
            </div>
          </div>

          {index < steps.length - 1 && (
            <div
              className={`h-1 flex-1 mx-4 rounded-full transition-all ${
                index < currentIndex ? "bg-secondary" : "bg-muted"
              }`}
            ></div>
          )}
        </div>
      ))}
    </div>
  )
}
