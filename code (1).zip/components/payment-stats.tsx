"use client"

import { Card, CardContent } from "@/components/ui/card"
import { DollarSign, TrendingUp, AlertCircle, CheckCircle } from "lucide-react"

export function PaymentStats() {
  const stats = [
    {
      title: "Total Tagihan",
      value: "Rp 72.000.000",
      description: "4 invoice",
      icon: DollarSign,
      color: "text-accent",
    },
    {
      title: "Sudah Dibayar",
      value: "Rp 41.500.000",
      description: "58%",
      icon: CheckCircle,
      color: "text-green-500",
    },
    {
      title: "Tertunda",
      value: "Rp 12.500.000",
      description: "1 invoice",
      icon: TrendingUp,
      color: "text-secondary",
    },
    {
      title: "Terlambat",
      value: "Rp 18.000.000",
      description: "Perlu segera dibayar",
      icon: AlertCircle,
      color: "text-destructive",
    },
  ]

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {stats.map((stat, idx) => {
        const Icon = stat.icon
        return (
          <Card key={idx} className="border-border/50">
            <CardContent className="pt-6">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">{stat.title}</p>
                  <p className="text-2xl font-bold mt-2">{stat.value}</p>
                  <p className="text-xs text-muted-foreground mt-1">{stat.description}</p>
                </div>
                <Icon className={`w-6 h-6 ${stat.color}`} />
              </div>
            </CardContent>
          </Card>
        )
      })}
    </div>
  )
}
