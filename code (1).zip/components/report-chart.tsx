"use client"

import {
  BarChart,
  Bar,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts"

const shipmentData = [
  { month: "Jan", export: 45, import: 38 },
  { month: "Feb", export: 52, import: 42 },
  { month: "Mar", export: 48, import: 40 },
  { month: "Apr", export: 61, import: 55 },
  { month: "May", export: 55, import: 48 },
  { month: "Jun", export: 68, import: 62 },
]

const efficiencyData = [
  { stage: "Ordering", days: 1 },
  { stage: "Validation", days: 2 },
  { stage: "Planning", days: 1 },
  { stage: "Transit", days: 10 },
  { stage: "Clearance", days: 2 },
]

interface ReportChartProps {
  type: "shipment" | "efficiency"
}

export function ReportChart({ type }: ReportChartProps) {
  if (type === "shipment") {
    return (
      <ResponsiveContainer width="100%" height={300}>
        <BarChart data={shipmentData}>
          <CartesianGrid strokeDasharray="3 3" stroke="currentColor" opacity={0.1} />
          <XAxis dataKey="month" stroke="currentColor" opacity={0.5} />
          <YAxis stroke="currentColor" opacity={0.5} />
          <Tooltip />
          <Legend />
          <Bar dataKey="export" fill="hsl(var(--accent))" name="Ekspor" />
          <Bar dataKey="import" fill="hsl(var(--secondary))" name="Impor" />
        </BarChart>
      </ResponsiveContainer>
    )
  }

  return (
    <ResponsiveContainer width="100%" height={300}>
      <LineChart data={efficiencyData}>
        <CartesianGrid strokeDasharray="3 3" stroke="currentColor" opacity={0.1} />
        <XAxis dataKey="stage" stroke="currentColor" opacity={0.5} />
        <YAxis stroke="currentColor" opacity={0.5} />
        <Tooltip />
        <Legend />
        <Line
          type="monotone"
          dataKey="days"
          stroke="hsl(var(--accent))"
          strokeWidth={2}
          dot={{ fill: "hsl(var(--accent))", r: 4 }}
          activeDot={{ r: 6 }}
          name="Rata-rata Hari"
        />
      </LineChart>
    </ResponsiveContainer>
  )
}
