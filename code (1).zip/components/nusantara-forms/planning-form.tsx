"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Checkbox } from "@/components/ui/checkbox"
import { Check, Calendar, Truck } from "lucide-react"
import { useState } from "react"

interface PlanningFormProps {
  data: any
  onUpdate: (data: any) => void
  onBack: () => void
  onSubmit: () => void
}

export function NusantaraPlanningForm({ data, onUpdate, onBack, onSubmit }: PlanningFormProps) {
  const [isSubmitted, setIsSubmitted] = useState(false)

  const deliverySchedules = [
    { date: "2025-01-05", time: "09:00 - 17:00", capacity: "Available" },
    { date: "2025-01-06", time: "09:00 - 17:00", capacity: "Available" },
    { date: "2025-01-07", time: "09:00 - 12:00", capacity: "Limited" },
  ]

  const pickupTimes = [
    { time: "08:00 - 10:00", availability: "10 slot" },
    { time: "10:00 - 12:00", availability: "7 slot" },
    { time: "14:00 - 16:00", availability: "12 slot" },
  ]

  const handleDeliverySelect = (date: string) => {
    onUpdate({ deliverySchedule: date })
  }

  const handlePickupSelect = (time: string) => {
    onUpdate({ pickupTime: time })
  }

  const handleInsuranceToggle = () => {
    onUpdate({ insuranceRequested: !data.insuranceRequested })
  }

  const handleSubmit = () => {
    setIsSubmitted(true)
    setTimeout(() => {
      onSubmit()
    }, 1500)
  }

  if (isSubmitted) {
    return (
      <Card className="border-border/50">
        <CardHeader>
          <CardTitle className="text-2xl">Pengiriman Domestik Berhasil Didaftarkan</CardTitle>
          <CardDescription>Pesanan pengiriman Anda telah diproses</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="bg-green-500/10 border border-green-500/20 rounded-lg p-6 space-y-4">
            <div className="flex items-center justify-center w-12 h-12 mx-auto bg-green-500/20 rounded-full">
              <Check className="w-6 h-6 text-green-600" />
            </div>
            <div className="text-center space-y-2">
              <p className="font-semibold">Nomor Pengiriman Domestik</p>
              <p className="text-2xl font-bold text-secondary">
                NUS-2025-{String(Math.floor(Math.random() * 9000) + 1000).padStart(5, "0")}
              </p>
            </div>
          </div>

          <div className="space-y-4 bg-muted/30 rounded-lg p-4">
            <div className="flex items-center justify-between py-2">
              <span className="text-sm text-muted-foreground">Rute</span>
              <span className="font-semibold">
                {data.origin} → {data.destination}
              </span>
            </div>
            <div className="flex items-center justify-between py-2">
              <span className="text-sm text-muted-foreground">Jadwal Pengiriman</span>
              <span className="font-semibold">{data.deliverySchedule}</span>
            </div>
            <div className="flex items-center justify-between py-2">
              <span className="text-sm text-muted-foreground">Waktu Penjemputan</span>
              <span className="font-semibold">{data.pickupTime}</span>
            </div>
            {data.insuranceRequested && (
              <div className="flex items-center justify-between py-2 border-t border-muted pt-2">
                <span className="text-sm text-muted-foreground">Asuransi Pengiriman</span>
                <span className="font-semibold text-green-600">Aktif</span>
              </div>
            )}
          </div>

          <div className="bg-blue-500/10 border border-blue-500/20 rounded-lg p-4">
            <p className="text-sm text-muted-foreground">
              <strong>Langkah Berikutnya:</strong> Anda akan menerima notifikasi jadwal pengiriman dan dapat memantau
              status pengiriman di dashboard tracking.
            </p>
          </div>

          <div className="flex gap-3 justify-end pt-4">
            <Button variant="outline" onClick={() => (window.location.href = "/dashboard")}>
              Kembali ke Dashboard
            </Button>
            <Button className="gap-2">
              <Calendar className="w-4 h-4" />
              Lihat Pengiriman
            </Button>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card className="border-border/50">
      <CardHeader>
        <CardTitle className="text-2xl">Langkah 3: Penjadwalan Pengiriman</CardTitle>
        <CardDescription>Pilih jadwal pengiriman dan waktu penjemputan</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* AI Recommendation */}
        <div className="bg-secondary/5 border border-secondary/20 rounded-lg p-4">
          <p className="text-sm">
            <strong>Rekomendasi AI:</strong> Berdasarkan kondisi jalan dan kapasitas, jadwal pengiriman{" "}
            <span className="text-secondary font-semibold">{deliverySchedules[0].date}</span> dengan pickup{" "}
            <span className="text-secondary font-semibold">{pickupTimes[2].time}</span> adalah optimal.
          </p>
        </div>

        {/* Delivery Schedule */}
        <div className="space-y-4">
          <h3 className="font-semibold">Pilih Jadwal Pengiriman</h3>
          <div className="space-y-3">
            {deliverySchedules.map((schedule) => (
              <button
                key={schedule.date}
                onClick={() => handleDeliverySelect(schedule.date)}
                className={`w-full text-left p-4 border rounded-lg transition-all ${
                  data.deliverySchedule === schedule.date
                    ? "border-secondary bg-secondary/5"
                    : "border-border hover:border-secondary/50"
                }`}
              >
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-semibold">{schedule.date}</p>
                    <p className="text-sm text-muted-foreground">{schedule.time}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-xs text-muted-foreground">Status</p>
                    <p className="font-semibold text-green-600">{schedule.capacity}</p>
                  </div>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Pickup Time */}
        <div className="space-y-4">
          <h3 className="font-semibold">Pilih Waktu Penjemputan</h3>
          <div className="space-y-3">
            {pickupTimes.map((option) => (
              <button
                key={option.time}
                onClick={() => handlePickupSelect(option.time)}
                className={`w-full text-left p-4 border rounded-lg transition-all flex items-center justify-between ${
                  data.pickupTime === option.time
                    ? "border-secondary bg-secondary/5"
                    : "border-border hover:border-secondary/50"
                }`}
              >
                <div className="flex items-center gap-3">
                  <Truck className="w-5 h-5 text-secondary" />
                  <div>
                    <p className="font-semibold">{option.time}</p>
                    <p className="text-sm text-muted-foreground">{option.availability} tersedia</p>
                  </div>
                </div>
                {data.pickupTime === option.time && <Check className="w-5 h-5 text-secondary" />}
              </button>
            ))}
          </div>
        </div>

        {/* Additional Services */}
        <div className="space-y-4">
          <h3 className="font-semibold">Layanan Tambahan</h3>
          <label className="flex items-center gap-3 p-3 border border-border rounded-lg hover:bg-muted/50 cursor-pointer transition-colors">
            <Checkbox checked={data.insuranceRequested} onCheckedChange={handleInsuranceToggle} />
            <div className="flex-1">
              <p className="text-sm font-medium">Asuransi Pengiriman</p>
              <p className="text-xs text-muted-foreground">Perlindungan untuk kemungkinan kerusakan atau hilang</p>
            </div>
          </label>
        </div>

        {/* Summary */}
        <div className="space-y-4 bg-muted/30 rounded-lg p-4">
          <h3 className="font-semibold text-sm">Ringkasan Jadwal</h3>
          {data.deliverySchedule && (
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Jadwal Pengiriman</span>
                <span className="font-semibold">{data.deliverySchedule}</span>
              </div>
              {data.pickupTime && (
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Waktu Penjemputan</span>
                  <span className="font-semibold">{data.pickupTime}</span>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Action Buttons */}
        <div className="flex justify-between pt-4">
          <Button variant="outline" onClick={onBack}>
            Kembali
          </Button>
          <Button onClick={handleSubmit} disabled={!data.deliverySchedule || !data.pickupTime} className="gap-2">
            <Check className="w-4 h-4" />
            Selesaikan Pemesanan
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}
