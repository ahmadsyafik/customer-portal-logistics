"use client"

import type React from "react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { ArrowRight, Truck } from "lucide-react"

interface OrderingFormProps {
  data: any
  onUpdate: (data: any) => void
  onNext: () => void
  onCancel: () => void
}

export function NusantaraOrderingForm({ data, onUpdate, onNext, onCancel }: OrderingFormProps) {
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    onUpdate({ [name]: value })
  }

  const handleSelectChange = (field: string, value: string) => {
    onUpdate({ [field]: value })
  }

  const indonesianCities = [
    "Jakarta",
    "Surabaya",
    "Medan",
    "Makassar",
    "Bandung",
    "Yogyakarta",
    "Bali",
    "Semarang",
    "Palembang",
    "Pontianak",
    "Manado",
    "Banjarmasin",
  ]

  const serviceTypes = ["Regular (5-6 hari)", "Express (2-3 hari)", "Overnight", "Same Day"]
  const goodsTypes = ["General Cargo", "Perishable", "Electronics", "Furniture", "Fragile", "Other"]

  return (
    <Card className="border-border/50">
      <CardHeader>
        <CardTitle className="text-2xl">Langkah 1: Pemesanan Pengiriman Domestik</CardTitle>
        <CardDescription>Isi informasi pengiriman Anda di dalam Indonesia</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Sender Info */}
        <div className="space-y-4">
          <h3 className="font-semibold">Informasi Pengirim</h3>
          <div className="grid md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="sender">Nama Pengirim</Label>
              <Input
                id="sender"
                name="sender"
                placeholder="PT. Maju Jaya"
                value={data.sender}
                onChange={handleChange}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="senderEmail">Email Pengirim</Label>
              <Input
                id="senderEmail"
                name="senderEmail"
                type="email"
                placeholder="contact@majujaya.com"
                value={data.senderEmail}
                onChange={handleChange}
              />
            </div>
            <div className="space-y-2 md:col-span-2">
              <Label htmlFor="senderPhone">Telepon Pengirim</Label>
              <Input
                id="senderPhone"
                name="senderPhone"
                placeholder="+62-21-xxxx-xxxx"
                value={data.senderPhone}
                onChange={handleChange}
              />
            </div>
          </div>
        </div>

        {/* Recipient Info */}
        <div className="space-y-4">
          <h3 className="font-semibold">Informasi Penerima</h3>
          <div className="space-y-2">
            <Label htmlFor="recipient">Nama Penerima</Label>
            <Input
              id="recipient"
              name="recipient"
              placeholder="Nama penerima barang"
              value={data.recipient}
              onChange={handleChange}
            />
          </div>
        </div>

        {/* Shipping Route */}
        <div className="space-y-4">
          <h3 className="font-semibold flex items-center gap-2">
            <Truck className="w-5 h-5" />
            Rute Pengiriman
          </h3>
          <div className="grid md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="origin">Kota Asal</Label>
              <Select value={data.origin} onValueChange={(value) => handleSelectChange("origin", value)}>
                <SelectTrigger id="origin">
                  <SelectValue placeholder="Pilih kota asal" />
                </SelectTrigger>
                <SelectContent>
                  {indonesianCities.map((city) => (
                    <SelectItem key={city} value={city}>
                      {city}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="destination">Kota Tujuan</Label>
              <Select value={data.destination} onValueChange={(value) => handleSelectChange("destination", value)}>
                <SelectTrigger id="destination">
                  <SelectValue placeholder="Pilih kota tujuan" />
                </SelectTrigger>
                <SelectContent>
                  {indonesianCities.map((city) => (
                    <SelectItem key={city} value={city}>
                      {city}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>

        {/* Goods Info */}
        <div className="space-y-4">
          <h3 className="font-semibold">Detail Barang</h3>
          <div className="grid md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="goodsType">Jenis Barang</Label>
              <Select value={data.goodsType} onValueChange={(value) => handleSelectChange("goodsType", value)}>
                <SelectTrigger id="goodsType">
                  <SelectValue placeholder="Pilih jenis barang" />
                </SelectTrigger>
                <SelectContent>
                  {goodsTypes.map((type) => (
                    <SelectItem key={type} value={type}>
                      {type}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="serviceType">Tipe Layanan</Label>
              <Select value={data.serviceType} onValueChange={(value) => handleSelectChange("serviceType", value)}>
                <SelectTrigger id="serviceType">
                  <SelectValue placeholder="Pilih tipe layanan" />
                </SelectTrigger>
                <SelectContent>
                  {serviceTypes.map((service) => (
                    <SelectItem key={service} value={service}>
                      {service}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="quantity">Jumlah Barang (Unit)</Label>
              <Input
                id="quantity"
                name="quantity"
                type="number"
                placeholder="100"
                value={data.quantity}
                onChange={handleChange}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="weight">Berat Total (kg)</Label>
              <Input
                id="weight"
                name="weight"
                type="number"
                placeholder="500"
                value={data.weight}
                onChange={handleChange}
              />
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex justify-end gap-3 pt-4">
          <Button variant="outline" onClick={onCancel}>
            Batal
          </Button>
          <Button
            onClick={onNext}
            disabled={!data.sender || !data.origin || !data.destination || !data.goodsType || !data.weight}
            className="gap-2"
          >
            Lanjut ke Validasi <ArrowRight className="w-4 h-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}
