"use client"

import type React from "react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { ArrowRight, Check, AlertCircle } from "lucide-react"

interface ValidatingFormProps {
  data: any
  onUpdate: (data: any) => void
  onNext: () => void
  onBack: () => void
}

export function NusantaraValidatingForm({ data, onUpdate, onNext, onBack }: ValidatingFormProps) {
  const handleAdvancePayment = (e: React.ChangeEvent<HTMLInputElement>) => {
    onUpdate({ advancePayment: e.target.value })
  }

  const handleApprove = () => {
    onUpdate({ documentStatus: "approved" })
  }

  const estimatedCost = Math.floor(Math.random() * 8) + 2

  return (
    <Card className="border-border/50">
      <CardHeader>
        <CardTitle className="text-2xl">Langkah 2: Validasi & Pembayaran</CardTitle>
        <CardDescription>Verifikasi detail pengiriman dan lakukan pembayaran awal</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Validation Status */}
        <div className="bg-secondary/5 border border-secondary/20 rounded-lg p-4">
          <div className="flex gap-3">
            <AlertCircle className="w-5 h-5 text-secondary flex-shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold text-sm">Validasi Detail Pengiriman</p>
              <p className="text-sm text-muted-foreground mt-1">
                Sistem kami sedang memvalidasi informasi pengiriman dan menghitung biaya optimal berdasarkan rute,
                berat, dan layanan pilihan.
              </p>
            </div>
          </div>
        </div>

        {/* Shipment Summary */}
        <div className="space-y-4">
          <h3 className="font-semibold">Ringkasan Pengiriman</h3>
          <div className="grid md:grid-cols-2 gap-4 bg-muted/30 rounded-lg p-4">
            <div>
              <p className="text-sm text-muted-foreground">Pengirim</p>
              <p className="font-medium">{data.sender}</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Penerima</p>
              <p className="font-medium">{data.recipient}</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Rute</p>
              <p className="font-medium">
                {data.origin} → {data.destination}
              </p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Jenis Barang</p>
              <p className="font-medium">{data.goodsType}</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Berat</p>
              <p className="font-medium">{data.weight} kg</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Layanan</p>
              <p className="font-medium">{data.serviceType}</p>
            </div>
          </div>
        </div>

        {/* Payment Info */}
        <div className="space-y-4">
          <h3 className="font-semibold">Detail Pembayaran</h3>
          <div className="bg-secondary/5 border border-secondary/20 rounded-lg p-4 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm">Biaya Pengiriman</span>
              <span className="font-semibold">Rp {estimatedCost * 1000000}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm">Biaya Admin & Handling</span>
              <span className="font-semibold">Rp 250.000</span>
            </div>
            <div className="border-t border-secondary/20 pt-3">
              <div className="flex items-center justify-between">
                <span className="text-sm font-semibold">Pembayaran Awal (30%)</span>
                <span className="font-bold text-secondary">
                  Rp {Math.floor((estimatedCost * 1000000 + 250000) * 0.3)}
                </span>
              </div>
            </div>
            <div className="space-y-2 mt-4">
              <Label htmlFor="advancePayment">Kode Referensi Pembayaran</Label>
              <Input
                id="advancePayment"
                placeholder="Masukkan kode setelah transfer"
                value={data.advancePayment}
                onChange={handleAdvancePayment}
              />
              <p className="text-xs text-muted-foreground">
                Transfer ke rekening yang tersedia dan masukkan kode referensi
              </p>
            </div>
          </div>
        </div>

        {/* Status */}
        {data.documentStatus === "approved" && (
          <div className="bg-green-500/10 border border-green-500/20 rounded-lg p-4 flex gap-3">
            <Check className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold text-sm text-green-600">Pembayaran Diverifikasi</p>
              <p className="text-sm text-green-600/80 mt-1">
                Pembayaran Anda telah diterima dan diverifikasi. Anda dapat melanjutkan ke tahap penjadwalan pengiriman.
              </p>
            </div>
          </div>
        )}

        {/* Action Buttons */}
        <div className="flex justify-between pt-4">
          <Button variant="outline" onClick={onBack}>
            Kembali
          </Button>
          <div className="flex gap-3">
            {data.documentStatus !== "approved" && (
              <Button variant="outline" onClick={handleApprove}>
                Verifikasi Pembayaran
              </Button>
            )}
            {data.documentStatus === "approved" && (
              <Button onClick={onNext} className="gap-2">
                Lanjut ke Penjadwalan <ArrowRight className="w-4 h-4" />
              </Button>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
