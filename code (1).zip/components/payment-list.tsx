"use client"

import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Eye, Download } from "lucide-react"

interface Payment {
  id: string
  shipmentId: string
  type: string
  description: string
  amount: number
  status: "pending" | "paid" | "overdue"
  dueDate: string
  paidDate: string | null
  invoiceDate: string
}

interface PaymentListProps {
  payments: Payment[]
}

export function PaymentList({ payments }: PaymentListProps) {
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("id-ID", {
      style: "currency",
      currency: "IDR",
      minimumFractionDigits: 0,
    }).format(amount)
  }

  const formatDate = (date: string) => {
    return new Date(date).toLocaleDateString("id-ID", {
      year: "numeric",
      month: "short",
      day: "numeric",
    })
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "paid":
        return "bg-green-500/10 text-green-600 border-green-500/20"
      case "pending":
        return "bg-secondary/10 text-secondary border-secondary/20"
      case "overdue":
        return "bg-destructive/10 text-destructive border-destructive/20"
      default:
        return ""
    }
  }

  const getStatusLabel = (status: string) => {
    switch (status) {
      case "paid":
        return "Dibayar"
      case "pending":
        return "Tertunda"
      case "overdue":
        return "Terlambat"
      default:
        return status
    }
  }

  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm">
        <thead>
          <tr className="border-b border-border">
            <th className="text-left py-3 px-4 font-semibold">No. Invoice</th>
            <th className="text-left py-3 px-4 font-semibold">Pengiriman</th>
            <th className="text-left py-3 px-4 font-semibold">Deskripsi</th>
            <th className="text-right py-3 px-4 font-semibold">Jumlah</th>
            <th className="text-left py-3 px-4 font-semibold">Status</th>
            <th className="text-left py-3 px-4 font-semibold">Due Date</th>
            <th className="text-left py-3 px-4 font-semibold">Aksi</th>
          </tr>
        </thead>
        <tbody>
          {payments.map((payment) => (
            <tr key={payment.id} className="border-b border-border/50 hover:bg-muted/30 transition-colors">
              <td className="py-4 px-4 font-mono font-semibold text-accent">{payment.id}</td>
              <td className="py-4 px-4">
                <div className="flex items-center gap-2">
                  <span className="font-mono text-xs">{payment.shipmentId}</span>
                  <Badge variant="outline" className="text-xs">
                    {payment.type}
                  </Badge>
                </div>
              </td>
              <td className="py-4 px-4 text-muted-foreground">{payment.description}</td>
              <td className="py-4 px-4 font-semibold text-right">{formatCurrency(payment.amount)}</td>
              <td className="py-4 px-4">
                <Badge className={`text-xs border ${getStatusColor(payment.status)}`}>
                  {getStatusLabel(payment.status)}
                </Badge>
              </td>
              <td className="py-4 px-4 text-muted-foreground">
                <div>
                  <p>{formatDate(payment.dueDate)}</p>
                  {payment.paidDate && (
                    <p className="text-xs text-green-600">Dibayar: {formatDate(payment.paidDate)}</p>
                  )}
                </div>
              </td>
              <td className="py-4 px-4">
                <div className="flex gap-2">
                  <Button variant="ghost" size="sm" className="gap-2">
                    <Eye className="w-4 h-4" />
                  </Button>
                  <Button variant="ghost" size="sm" className="gap-2">
                    <Download className="w-4 h-4" />
                  </Button>
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
