"use client"

import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts"

const data = [
  { date: "1 Jan", export: 24, import: 18 },
  { date: "8 Jan", export: 32, import: 25 },
  { date: "15 Jan", export: 28, import: 22 },
  { date: "22 Jan", export: 35, import: 28 },
  { date: "29 Jan", export: 38, import: 32 },
]

export function ShipmentChart() {
  return (
    <ResponsiveContainer width="100%" height={300}>
      <LineChart data={data}>
        <CartesianGrid strokeDasharray="3 3" stroke="currentColor" opacity={0.1} />
        <XAxis dataKey="date" stroke="currentColor" opacity={0.5} />
        <YAxis stroke="currentColor" opacity={0.5} />
        <Tooltip />
        <Legend />
        <Line
          type="monotone"
          dataKey="export"
          stroke="hsl(var(--accent))"
          strokeWidth={2}
          dot={{ fill: "hsl(var(--accent))", r: 4 }}
          activeDot={{ r: 6 }}
          name="Ekspor"
        />
        <Line
          type="monotone"
          dataKey="import"
          stroke="hsl(var(--secondary))"
          strokeWidth={2}
          dot={{ fill: "hsl(var(--secondary))", r: 4 }}
          activeDot={{ r: 6 }}
          name="Impor"
        />
      </LineChart>
    </ResponsiveContainer>
  )
}
