"use client"

import { Check, Clock, AlertCircle } from "lucide-react"

interface ShipmentTimelineProps {
  shipmentId: string
  isExport: boolean
}

export function ShipmentTimeline({ shipmentId, isExport }: ShipmentTimelineProps) {
  const events = isExport
    ? [
        {
          status: "Pemesanan Diterima",
          date: "2025-01-01",
          time: "10:30",
          completed: true,
          description: "Pesanan ekspor Anda telah diterima dan diproses",
        },
        {
          status: "Dokumen Tervalidasi",
          date: "2025-01-02",
          time: "14:15",
          completed: true,
          description: "Semua dokumen ekspor telah diverifikasi dan disetujui",
        },
        {
          status: "Kapal Berangkat",
          date: "2025-01-03",
          time: "08:00",
          completed: true,
          description: "Maersk Seatrade berangkat dari Pelabuhan Jakarta",
        },
        {
          status: "Pengiriman Dalam Perjalanan",
          date: "2025-01-04",
          time: "14:00",
          completed: true,
          description: "Pengiriman sedang dalam perjalanan ke tujuan",
          alert: "Cuaca buruk di Selat Malaka menyebabkan keterlambatan 4 jam",
        },
        {
          status: "Tiba di Tujuan (Est.)",
          date: "2025-01-15",
          time: "12:00",
          completed: false,
          description: "Diperkirakan tiba di pelabuhan tujuan",
        },
      ]
    : [
        {
          status: "Permintaan Diterima",
          date: "2025-01-01",
          time: "10:30",
          completed: true,
          description: "Permintaan impor Anda telah diterima",
        },
        {
          status: "Dokumen Terverifikasi",
          date: "2025-01-02",
          time: "14:15",
          completed: true,
          description: "Semua dokumen impor telah diverifikasi",
        },
        {
          status: "Kapal Dalam Perjalanan",
          date: "2025-01-04",
          time: "08:00",
          completed: true,
          description: "Ever Given sedang dalam perjalanan ke Jakarta",
        },
        {
          status: "Kapal Tiba di Pelabuhan",
          date: "2025-01-18",
          time: "06:00",
          completed: false,
          description: "Diperkirakan kapal tiba di pelabuhan Jakarta",
        },
        {
          status: "Proses Bongkar Muat",
          date: "2025-01-18",
          time: "Pending",
          completed: false,
          description: "Proses bongkar muat barang dari kapal",
        },
      ]

  return (
    <div className="space-y-6">
      {events.map((event, idx) => (
        <div key={idx} className="flex gap-4">
          <div className="flex flex-col items-center">
            <div
              className={`w-8 h-8 rounded-full flex items-center justify-center font-bold ${
                event.completed ? "bg-accent text-white" : "bg-muted text-muted-foreground"
              }`}
            >
              {event.completed ? <Check className="w-5 h-5" /> : <Clock className="w-5 h-5" />}
            </div>
            {idx < events.length - 1 && (
              <div className={`w-1 h-16 mt-2 ${event.completed ? "bg-accent" : "bg-muted"}`}></div>
            )}
          </div>

          <div className="flex-1 pb-4">
            <div className="flex items-baseline gap-2">
              <p className="font-semibold">{event.status}</p>
              <p className="text-xs text-muted-foreground">
                {event.date} • {event.time}
              </p>
            </div>
            <p className="text-sm text-muted-foreground mt-1">{event.description}</p>
            {event.alert && (
              <div className="mt-3 p-2 bg-secondary/10 border border-secondary/20 rounded flex gap-2 text-xs">
                <AlertCircle className="w-4 h-4 text-secondary flex-shrink-0 mt-0.5" />
                <p className="text-secondary">{event.alert}</p>
              </div>
            )}
          </div>
        </div>
      ))}
    </div>
  )
}
