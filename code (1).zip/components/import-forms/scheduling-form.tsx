"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Checkbox } from "@/components/ui/checkbox"
import { Check, Calendar, Truck } from "lucide-react"
import { useState } from "react"
import Link from "next/link"

interface SchedulingFormProps {
  data: any
  onUpdate: (data: any) => void
  onBack: () => void
}

export function ImportSchedulingForm({ data, onUpdate, onBack }: SchedulingFormProps) {
  const [isSubmitted, setIsSubmitted] = useState(false)

  const dischargingSchedules = [
    { date: "2025-01-15", time: "08:00 - 16:00", capacity: "Full" },
    { date: "2025-01-16", time: "08:00 - 16:00", capacity: "Full" },
    { date: "2025-01-17", time: "08:00 - 12:00", capacity: "Half" },
  ]

  const truckPickupTimes = [
    { time: "09:00 - 11:00", availability: "5 slot" },
    { time: "11:00 - 13:00", availability: "3 slot" },
    { time: "14:00 - 16:00", availability: "8 slot" },
  ]

  const handleDischargingSelect = (date: string) => {
    onUpdate({ dischargingSchedule: date })
  }

  const handleTruckPickupSelect = (time: string) => {
    onUpdate({ truckPickupTime: time })
  }

  const handleGatePassToggle = () => {
    onUpdate({ gatePassRequested: !data.gatePassRequested })
  }

  const handleSubmit = () => {
    setIsSubmitted(true)
  }

  if (isSubmitted) {
    return (
      <Card className="border-border/50">
        <CardHeader>
          <CardTitle className="text-2xl">Pengiriman Impor Berhasil Didaftarkan</CardTitle>
          <CardDescription>Pesanan impor Anda telah diproses</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="bg-green-500/10 border border-green-500/20 rounded-lg p-6 space-y-4">
            <div className="flex items-center justify-center w-12 h-12 mx-auto bg-green-500/20 rounded-full">
              <Check className="w-6 h-6 text-green-600" />
            </div>
            <div className="text-center space-y-2">
              <p className="font-semibold">Nomor Pengiriman Impor</p>
              <p className="text-2xl font-bold text-secondary">IMP-2025-005678</p>
            </div>
          </div>

          <div className="space-y-4 bg-muted/30 rounded-lg p-4">
            <div className="flex items-center justify-between py-2">
              <span className="text-sm text-muted-foreground">Kapal</span>
              <span className="font-semibold">{data.vesselName}</span>
            </div>
            <div className="flex items-center justify-between py-2">
              <span className="text-sm text-muted-foreground">ETA Kedatangan</span>
              <span className="font-semibold">{data.eta}</span>
            </div>
            <div className="flex items-center justify-between py-2">
              <span className="text-sm text-muted-foreground">Jadwal Bongkar</span>
              <span className="font-semibold">{data.dischargingSchedule}</span>
            </div>
            <div className="flex items-center justify-between py-2">
              <span className="text-sm text-muted-foreground">Penjemputan Truck</span>
              <span className="font-semibold">{data.truckPickupTime}</span>
            </div>
            {data.gatePassRequested && (
              <div className="flex items-center justify-between py-2 border-t border-muted pt-2">
                <span className="text-sm text-muted-foreground">Gate Pass</span>
                <span className="font-semibold text-green-600">Diminta</span>
              </div>
            )}
          </div>

          <div className="bg-blue-500/10 border border-blue-500/20 rounded-lg p-4">
            <p className="text-sm text-muted-foreground">
              <strong>Langkah Berikutnya:</strong> Anda akan menerima konfirmasi jadwal bongkar dan dapat memantau
              status di dashboard tracking.
            </p>
          </div>

          <div className="flex gap-3 justify-end pt-4">
            <Link href="/dashboard">
              <Button variant="outline">Kembali ke Dashboard</Button>
            </Link>
            <Link href="/dashboard/tracking/IMP-2025-005678">
              <Button className="gap-2">
                <Calendar className="w-4 h-4" />
                Lihat Detail Pengiriman
              </Button>
            </Link>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card className="border-border/50">
      <CardHeader>
        <CardTitle className="text-2xl">Langkah 3: Penjadwalan Bongkar & Penjemputan</CardTitle>
        <CardDescription>Pilih jadwal bongkar muat dan waktu penjemputan kontainer</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* AI Recommendation */}
        <div className="bg-secondary/5 border border-secondary/20 rounded-lg p-4">
          <p className="text-sm">
            <strong>Rekomendasi AI:</strong> Berdasarkan kondisi pelabuhan, jadwal bongkar{" "}
            <span className="text-secondary font-semibold">{dischargingSchedules[0].date}</span> dengan pickup truck{" "}
            <span className="text-secondary font-semibold">{truckPickupTimes[2].time}</span> adalah optimal untuk
            menghindari penumpukan.
          </p>
        </div>

        {/* Discharging Schedule */}
        <div className="space-y-4">
          <h3 className="font-semibold">Pilih Jadwal Bongkar Muat</h3>
          <div className="space-y-3">
            {dischargingSchedules.map((schedule) => (
              <button
                key={schedule.date}
                onClick={() => handleDischargingSelect(schedule.date)}
                className={`w-full text-left p-4 border rounded-lg transition-all ${
                  data.dischargingSchedule === schedule.date
                    ? "border-secondary bg-secondary/5"
                    : "border-border hover:border-secondary/50"
                }`}
              >
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-semibold">{schedule.date}</p>
                    <p className="text-sm text-muted-foreground">{schedule.time}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-xs text-muted-foreground">Kapasitas</p>
                    <p className="font-semibold">{schedule.capacity}</p>
                  </div>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Truck Pickup Time */}
        <div className="space-y-4">
          <h3 className="font-semibold">Pilih Waktu Penjemputan Truck</h3>
          <div className="space-y-3">
            {truckPickupTimes.map((option) => (
              <button
                key={option.time}
                onClick={() => handleTruckPickupSelect(option.time)}
                className={`w-full text-left p-4 border rounded-lg transition-all flex items-center justify-between ${
                  data.truckPickupTime === option.time
                    ? "border-secondary bg-secondary/5"
                    : "border-border hover:border-secondary/50"
                }`}
              >
                <div className="flex items-center gap-3">
                  <Truck className="w-5 h-5 text-secondary" />
                  <div>
                    <p className="font-semibold">{option.time}</p>
                    <p className="text-sm text-muted-foreground">{option.availability} tersedia</p>
                  </div>
                </div>
                {data.truckPickupTime === option.time && <Check className="w-5 h-5 text-secondary" />}
              </button>
            ))}
          </div>
        </div>

        {/* Additional Services */}
        <div className="space-y-4">
          <h3 className="font-semibold">Layanan Tambahan</h3>
          <label className="flex items-center gap-3 p-3 border border-border rounded-lg hover:bg-muted/50 cursor-pointer transition-colors">
            <Checkbox checked={data.gatePassRequested} onCheckedChange={handleGatePassToggle} />
            <div className="flex-1">
              <p className="text-sm font-medium">Minta Gate Pass</p>
              <p className="text-xs text-muted-foreground">Untuk memudahkan pengambilan barang dari terminal</p>
            </div>
          </label>
        </div>

        {/* Summary */}
        <div className="space-y-4 bg-muted/30 rounded-lg p-4">
          <h3 className="font-semibold text-sm">Ringkasan Jadwal</h3>
          {data.dischargingSchedule && (
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Jadwal Bongkar</span>
                <span className="font-semibold">{data.dischargingSchedule}</span>
              </div>
              {data.truckPickupTime && (
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Pickup Truck</span>
                  <span className="font-semibold">{data.truckPickupTime}</span>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Action Buttons */}
        <div className="flex justify-between pt-4">
          <Button variant="outline" onClick={onBack}>
            Kembali
          </Button>
          <Button
            onClick={handleSubmit}
            disabled={!data.dischargingSchedule || !data.truckPickupTime}
            className="gap-2"
          >
            <Check className="w-4 h-4" />
            Selesaikan Penjadwalan
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}
