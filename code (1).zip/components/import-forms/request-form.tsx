"use client"

import type React from "react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { ArrowRight, Ship } from "lucide-react"

interface RequestFormProps {
  data: any
  onUpdate: (data: any) => void
  onNext: () => void
}

export function ImportRequestForm({ data, onUpdate, onNext }: RequestFormProps) {
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    onUpdate({ [name]: value })
  }

  return (
    <Card className="border-border/50">
      <CardHeader>
        <CardTitle className="text-2xl">Langkah 1: Permintaan Layanan Impor</CardTitle>
        <CardDescription>Isi informasi impor dan data kapal yang akan tiba</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Importer Info */}
        <div className="space-y-4">
          <h3 className="font-semibold">Informasi Importer (Penerima)</h3>
          <div className="grid md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="importer">Nama Importer</Label>
              <Input
                id="importer"
                name="importer"
                placeholder="PT. Distributor Indonesia"
                value={data.importer}
                onChange={handleChange}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="importerEmail">Email Importer</Label>
              <Input
                id="importerEmail"
                name="importerEmail"
                type="email"
                placeholder="contact@distributor.com"
                value={data.importerEmail}
                onChange={handleChange}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="importerPhone">Telepon Importer</Label>
              <Input
                id="importerPhone"
                name="importerPhone"
                placeholder="+62-21-xxxx-xxxx"
                value={data.importerPhone}
                onChange={handleChange}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="shipper">Nama Shipper (Pengirim)</Label>
              <Input
                id="shipper"
                name="shipper"
                placeholder="ABC Corporation Ltd"
                value={data.shipper}
                onChange={handleChange}
              />
            </div>
          </div>
        </div>

        {/* Import Details */}
        <div className="space-y-4">
          <h3 className="font-semibold">Detail Impor</h3>
          <div className="grid md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="origin">Negara Asal</Label>
              <Input
                id="origin"
                name="origin"
                placeholder="China, Vietnam, Malaysia, dll"
                value={data.origin}
                onChange={handleChange}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="goodsType">Jenis Barang</Label>
              <Input
                id="goodsType"
                name="goodsType"
                placeholder="Mesin, Bahan Baku, Spare Parts, dll"
                value={data.goodsType}
                onChange={handleChange}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="quantity">Jumlah (Unit)</Label>
              <Input
                id="quantity"
                name="quantity"
                type="number"
                placeholder="200"
                value={data.quantity}
                onChange={handleChange}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="weight">Berat (Ton)</Label>
              <Input
                id="weight"
                name="weight"
                type="number"
                placeholder="75"
                value={data.weight}
                onChange={handleChange}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="containerType">Tipe Kontainer</Label>
              <Input
                id="containerType"
                name="containerType"
                placeholder="20ft, 40ft, High Cube"
                value={data.containerType}
                onChange={handleChange}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="hsCode">Kode HS (Harmonized System)</Label>
              <Input id="hsCode" name="hsCode" placeholder="8704.32.10" value={data.hsCode} onChange={handleChange} />
            </div>
          </div>
        </div>

        {/* Vessel Info */}
        <div className="space-y-4">
          <h3 className="font-semibold flex items-center gap-2">
            <Ship className="w-5 h-5" />
            Informasi Kapal
          </h3>
          <div className="grid md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="vesselName">Nama Kapal</Label>
              <Input
                id="vesselName"
                name="vesselName"
                placeholder="Nama kapal yang akan tiba"
                value={data.vesselName}
                onChange={handleChange}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="eta">ETA (Estimated Time of Arrival)</Label>
              <Input id="eta" name="eta" type="date" value={data.eta} onChange={handleChange} />
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex justify-end gap-3 pt-4">
          <Button variant="outline">Batal</Button>
          <Button onClick={onNext} className="gap-2">
            Lanjut ke Verifikasi <ArrowRight className="w-4 h-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}
