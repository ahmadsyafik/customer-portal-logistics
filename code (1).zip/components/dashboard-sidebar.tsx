"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { BarChart3, Package, TrendingUp, FileText, Settings, ChevronLeft, Globe } from "lucide-react"

interface DashboardSidebarProps {
  isOpen: boolean
  setIsOpen: (open: boolean) => void
}

export function DashboardSidebar({ isOpen, setIsOpen }: DashboardSidebarProps) {
  const pathname = usePathname()

  const menuItems = [
    { href: "/dashboard", icon: BarChart3, label: "Dashboard", exact: true },
    { href: "/dashboard/export", icon: TrendingUp, label: "Ekspor Barang" },
    { href: "/dashboard/import", icon: Package, label: "Impor Barang" },
    { href: "/dashboard/nusantara", icon: Globe, label: "Logistik Nusantara" },
    { href: "/dashboard/shipments", icon: Package, label: "Daftar Pengiriman" },
    { href: "/dashboard/tracking", icon: TrendingUp, label: "Tracking" },
    { href: "/dashboard/reports", icon: FileText, label: "Laporan" },
    { href: "/dashboard/settings", icon: Settings, label: "Pengaturan" },
  ]

  return (
    <>
      {/* Desktop Sidebar */}
      <aside className="hidden md:flex flex-col w-64 bg-card border-r border-border min-h-screen">
        <div className="p-6 border-b border-border">
          <h2 className="text-lg font-semibold">Menu</h2>
        </div>

        <nav className="flex-1 p-4 space-y-2">
          {menuItems.map((item) => {
            const Icon = item.icon
            const isActive = item.exact ? pathname === item.href : pathname.startsWith(item.href)
            return (
              <Link
                key={item.href}
                href={item.href}
                className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
                  isActive
                    ? "bg-accent/10 text-accent font-semibold"
                    : "text-muted-foreground hover:text-foreground hover:bg-muted"
                }`}
              >
                <Icon className="w-5 h-5" />
                <span>{item.label}</span>
              </Link>
            )
          })}
        </nav>
      </aside>

      {/* Mobile Sidebar */}
      {isOpen && (
        <div className="fixed inset-0 z-40 md:hidden">
          <div className="absolute inset-0 bg-black/50" onClick={() => setIsOpen(false)}></div>
          <aside className="absolute left-0 top-0 bottom-0 w-64 bg-card border-r border-border flex flex-col">
            <div className="p-6 border-b border-border flex items-center justify-between">
              <h2 className="text-lg font-semibold">Menu</h2>
              <button onClick={() => setIsOpen(false)}>
                <ChevronLeft className="w-5 h-5" />
              </button>
            </div>
            <nav className="flex-1 p-4 space-y-2">
              {menuItems.map((item) => {
                const Icon = item.icon
                const isActive = item.exact ? pathname === item.href : pathname.startsWith(item.href)
                return (
                  <Link
                    key={item.href}
                    href={item.href}
                    className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
                      isActive
                        ? "bg-accent/10 text-accent font-semibold"
                        : "text-muted-foreground hover:text-foreground hover:bg-muted"
                    }`}
                    onClick={() => setIsOpen(false)}
                  >
                    <Icon className="w-5 h-5" />
                    <span>{item.label}</span>
                  </Link>
                )
              })}
            </nav>
          </aside>
        </div>
      )}
    </>
  )
}
