"use client"

import Link from "next/link"
import { useState } from "react"
import { Menu, X } from "lucide-react"
import { Button } from "@/components/ui/button"

export function Navbar() {
  const [isOpen, setIsOpen] = useState(false)

  return (
    <nav className="sticky top-0 z-50 backdrop-blur-md bg-background/80 border-b border-border">
      <div className="max-w-7xl mx-auto px-4 md:px-6 py-4">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-2 font-bold text-2xl">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-accent to-secondary"></div>
            <span className="text-foreground">ShipSmart</span>
          </Link>

          {/* Desktop Menu */}
          <div className="hidden md:flex items-center gap-8">
            <Link href="/features" className="text-sm font-medium hover:text-accent transition-colors">
              Fitur
            </Link>
            <Link href="/pricing" className="text-sm font-medium hover:text-accent transition-colors">
              Harga
            </Link>
            <Link href="/docs" className="text-sm font-medium hover:text-accent transition-colors">
              Dokumentasi
            </Link>
          </div>

          {/* Auth Buttons */}
          <div className="hidden md:flex items-center gap-4">
            <Link href="/auth/login">
              <Button variant="ghost">Login</Button>
            </Link>
            <Link href="/auth/signup">
              <Button>Daftar</Button>
            </Link>
          </div>

          {/* Mobile Menu Button */}
          <button className="md:hidden p-2" onClick={() => setIsOpen(!isOpen)}>
            {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {/* Mobile Menu */}
        {isOpen && (
          <div className="md:hidden mt-4 space-y-4 pb-4 border-t border-border pt-4">
            <Link href="/features" className="block text-sm font-medium">
              Fitur
            </Link>
            <Link href="/pricing" className="block text-sm font-medium">
              Harga
            </Link>
            <Link href="/docs" className="block text-sm font-medium">
              Dokumentasi
            </Link>
            <div className="flex flex-col gap-3 pt-4 border-t border-border">
              <Link href="/auth/login" className="w-full">
                <Button variant="ghost" className="w-full">
                  Login
                </Button>
              </Link>
              <Link href="/auth/signup" className="w-full">
                <Button className="w-full">Daftar</Button>
              </Link>
            </div>
          </div>
        )}
      </div>
    </nav>
  )
}
