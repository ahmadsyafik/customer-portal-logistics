"use client"

import { X, AlertCircle, CheckCircle } from "lucide-react"

interface NotificationCenterProps {
  onClose: () => void
}

export function NotificationCenter({ onClose }: NotificationCenterProps) {
  const notifications = [
    {
      id: 1,
      type: "warning",
      title: "Cuaca Buruk Terdeteksi",
      message: "Kapal Maersk Seatrade mengalami keterlambatan 4 jam karena kondisi laut bergelombang",
      timestamp: "5 menit lalu",
    },
    {
      id: 2,
      type: "success",
      title: "Pengiriman Berhasil",
      message: "Shipment SHP-003 telah tiba di Rotterdam dan telah dikonfirmasi penerima",
      timestamp: "2 jam lalu",
    },
    {
      id: 3,
      type: "warning",
      title: "Dokumentasi Tertunda",
      message: "Shipment SHP-002 memerlukan dokumen customs tambahan untuk segera diproses",
      timestamp: "1 jam lalu",
    },
  ]

  return (
    <div className="border border-border rounded-lg bg-card/50 backdrop-blur p-4">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <AlertCircle className="w-5 h-5 text-accent" />
          <h3 className="font-semibold">Notifikasi Penting</h3>
        </div>
        <button onClick={onClose} className="p-1 hover:bg-muted rounded transition-colors">
          <X className="w-4 h-4" />
        </button>
      </div>

      <div className="space-y-3">
        {notifications.map((notification) => (
          <div key={notification.id} className="flex gap-3 p-3 bg-background rounded-lg border border-border/50">
            {notification.type === "warning" ? (
              <AlertCircle className="w-5 h-5 text-secondary flex-shrink-0 mt-0.5" />
            ) : (
              <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0 mt-0.5" />
            )}
            <div className="flex-1 min-w-0">
              <p className="font-semibold text-sm">{notification.title}</p>
              <p className="text-xs text-muted-foreground mt-1">{notification.message}</p>
              <p className="text-xs text-muted-foreground/50 mt-2">{notification.timestamp}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
