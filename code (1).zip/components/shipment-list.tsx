"use client"

import { ChevronRight } from "lucide-react"
import Link from "next/link"
import { Progress } from "@/components/ui/progress"

interface Shipment {
  id: string
  type: "Ekspor" | "Impor"
  status: string
  destination: string
  progress: number
  vesselName: string
  eta: string
  cargo: string
}

interface ShipmentListProps {
  shipments: Shipment[]
}

export function ShipmentList({ shipments }: ShipmentListProps) {
  const getStatusColor = (status: string) => {
    switch (status) {
      case "In Transit":
        return "bg-accent/10 text-accent"
      case "Customs":
        return "bg-secondary/10 text-secondary"
      case "Loading":
        return "bg-accent/10 text-accent"
      case "Delivered":
        return "bg-green-500/10 text-green-600"
      default:
        return "bg-muted text-muted-foreground"
    }
  }

  return (
    <div className="space-y-4">
      {shipments.map((shipment) => (
        <Link key={shipment.id} href={`/dashboard/tracking/${shipment.id}`} className="block">
          <div className="border border-border rounded-lg p-4 hover:border-accent/50 hover:bg-muted/30 transition-all cursor-pointer">
            <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
              <div className="flex-1 space-y-3">
                <div className="flex items-center gap-3">
                  <span className="font-mono font-semibold text-accent">{shipment.id}</span>
                  <span className={`text-xs px-2 py-1 rounded-full font-semibold ${getStatusColor(shipment.status)}`}>
                    {shipment.status}
                  </span>
                  <span className="text-xs px-2 py-1 rounded-full bg-muted text-muted-foreground">{shipment.type}</span>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-xs text-muted-foreground">Tujuan</p>
                    <p className="font-medium">{shipment.destination}</p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Kapal</p>
                    <p className="font-medium">{shipment.vesselName}</p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Kargo</p>
                    <p className="font-medium">{shipment.cargo}</p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">ETA</p>
                    <p className="font-medium">{new Date(shipment.eta).toLocaleDateString("id-ID")}</p>
                  </div>
                </div>

                <div className="space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-muted-foreground">Progress</span>
                    <span className="text-xs font-semibold">{shipment.progress}%</span>
                  </div>
                  <Progress value={shipment.progress} className="h-2" />
                </div>
              </div>

              <ChevronRight className="w-5 h-5 text-muted-foreground hidden md:block" />
            </div>
          </div>
        </Link>
      ))}
    </div>
  )
}
