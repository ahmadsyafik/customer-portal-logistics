"use client"

import type React from "react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { ArrowRight, Check, AlertCircle } from "lucide-react"
import { useState } from "react"

interface ValidatingFormProps {
  data: any
  onUpdate: (data: any) => void
  onNext: () => void
  onBack: () => void
}

export function ExportValidatingForm({ data, onUpdate, onNext, onBack }: ValidatingFormProps) {
  const [uploadedFiles, setUploadedFiles] = useState<string[]>([])

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const fileName = e.target.files[0].name
      setUploadedFiles([...uploadedFiles, fileName])
      onUpdate({ documents: e.target.files[0] })
    }
  }

  const handleAdvancePayment = (e: React.ChangeEvent<HTMLInputElement>) => {
    onUpdate({ advancePayment: e.target.value })
  }

  const handleApprove = () => {
    onUpdate({ documentStatus: "approved" })
  }

  const requiredDocs = ["Surat Jalan (DO)", "Packing List", "Commercial Invoice", "Bill of Lading (B/L)"]

  return (
    <Card className="border-border/50">
      <CardHeader>
        <CardTitle className="text-2xl">Langkah 2: Validasi Dokumen & Pembayaran</CardTitle>
        <CardDescription>Verifikasi dokumen dan selesaikan pembayaran awal</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Validation Summary */}
        <div className="bg-accent/5 border border-accent/20 rounded-lg p-4">
          <div className="flex gap-3">
            <AlertCircle className="w-5 h-5 text-accent flex-shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold text-sm">Verifikasi Otomatis Sedang Berlangsung</p>
              <p className="text-sm text-muted-foreground mt-1">
                Sistem kami sedang memvalidasi data pengiriman Anda terhadap regulasi pelabuhan dan syarat-syarat
                layanan.
              </p>
            </div>
          </div>
        </div>

        {/* Shipment Summary */}
        <div className="space-y-4">
          <h3 className="font-semibold">Ringkasan Pengiriman</h3>
          <div className="grid md:grid-cols-2 gap-4 bg-muted/30 rounded-lg p-4">
            <div>
              <p className="text-sm text-muted-foreground">Pengirim</p>
              <p className="font-medium">{data.shipper}</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Penerima</p>
              <p className="font-medium">{data.consignee}</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Tujuan</p>
              <p className="font-medium">{data.destination}</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Jenis Barang</p>
              <p className="font-medium">{data.goodsType}</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Berat</p>
              <p className="font-medium">{data.weight} Ton</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Tipe Kontainer</p>
              <p className="font-medium">{data.containerType}</p>
            </div>
          </div>
        </div>

        {/* Document Upload */}
        <div className="space-y-4">
          <h3 className="font-semibold">Upload Dokumen</h3>
          <div className="space-y-3">
            {requiredDocs.map((doc) => (
              <div key={doc} className="flex items-center gap-3 p-3 border border-border rounded-lg">
                <input
                  type="checkbox"
                  className="w-4 h-4 rounded"
                  checked={uploadedFiles.includes(doc)}
                  onChange={(e) => {
                    if (e.target.checked) {
                      setUploadedFiles([...uploadedFiles, doc])
                    }
                  }}
                />
                <span className="flex-1 text-sm">{doc}</span>
                {uploadedFiles.includes(doc) && <Check className="w-4 h-4 text-green-500" />}
              </div>
            ))}
          </div>

          <div className="space-y-2">
            <Label htmlFor="docs">Upload Semua Dokumen (ZIP)</Label>
            <Input id="docs" type="file" onChange={handleFileUpload} accept=".pdf,.zip,.doc,.docx" />
            <p className="text-xs text-muted-foreground">Maksimal 50MB. Format: PDF, ZIP, DOC, atau DOCX</p>
          </div>
        </div>

        {/* Advance Payment */}
        <div className="space-y-4">
          <h3 className="font-semibold">Pembayaran Awal (Uang Pertanggungan)</h3>
          <div className="bg-secondary/5 border border-secondary/20 rounded-lg p-4 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm">Biaya Layanan Estimasi</span>
              <span className="font-semibold">Rp 25.000.000</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm">Pembayaran Awal (20%)</span>
              <span className="font-semibold text-secondary">Rp 5.000.000</span>
            </div>
            <div className="border-t border-secondary/20 pt-3">
              <Label htmlFor="advancePayment">Kode Referensi Pembayaran</Label>
              <Input
                id="advancePayment"
                placeholder="Masukkan kode setelah transfer"
                value={data.advancePayment}
                onChange={handleAdvancePayment}
                className="mt-2"
              />
            </div>
          </div>
        </div>

        {/* Status */}
        {data.documentStatus === "approved" && (
          <div className="bg-green-500/10 border border-green-500/20 rounded-lg p-4 flex gap-3">
            <Check className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold text-sm text-green-600">Validasi Berhasil</p>
              <p className="text-sm text-green-600/80 mt-1">
                Semua dokumen dan pembayaran telah diverifikasi. Anda dapat melanjutkan ke tahap perencanaan.
              </p>
            </div>
          </div>
        )}

        {/* Action Buttons */}
        <div className="flex justify-between pt-4">
          <Button variant="outline" onClick={onBack}>
            Kembali
          </Button>
          <div className="flex gap-3">
            {data.documentStatus !== "approved" && (
              <Button variant="outline" onClick={handleApprove}>
                Verifikasi & Lanjut
              </Button>
            )}
            {data.documentStatus === "approved" && (
              <Button onClick={onNext} className="gap-2">
                Lanjut ke Perencanaan <ArrowRight className="w-4 h-4" />
              </Button>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
