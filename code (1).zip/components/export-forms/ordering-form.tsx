"use client"

import type React from "react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"
import { ArrowRight } from "lucide-react"

interface OrderingFormProps {
  data: any
  onUpdate: (data: any) => void
  onNext: () => void
}

export function ExportOrderingForm({ data, onUpdate, onNext }: OrderingFormProps) {
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    onUpdate({ [name]: value })
  }

  const handleServiceToggle = (service: string) => {
    const services = data.services.includes(service)
      ? data.services.filter((s: string) => s !== service)
      : [...data.services, service]
    onUpdate({ services })
  }

  const services = [
    { id: "trucking", label: "Trucking (Angkutan Darat)" },
    { id: "stevedoring", label: "Stevedoring (Bongkar Muat)" },
    { id: "warehouse", label: "Warehouse (Pergudangan)" },
    { id: "documentation", label: "Documentation (Dokumentasi)" },
  ]

  return (
    <Card className="border-border/50">
      <CardHeader>
        <CardTitle className="text-2xl">Langkah 1: Pemesanan Layanan</CardTitle>
        <CardDescription>Isi informasi pengiriman dan pilih layanan yang dibutuhkan</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Shipper Info */}
        <div className="space-y-4">
          <h3 className="font-semibold">Informasi Pengirim</h3>
          <div className="grid md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="shipper">Nama Pengirim</Label>
              <Input
                id="shipper"
                name="shipper"
                placeholder="PT. Supplier Indonesia"
                value={data.shipper}
                onChange={handleChange}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="shipperEmail">Email Pengirim</Label>
              <Input
                id="shipperEmail"
                name="shipperEmail"
                type="email"
                placeholder="contact@supplier.com"
                value={data.shipperEmail}
                onChange={handleChange}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="shipperPhone">Telepon Pengirim</Label>
              <Input
                id="shipperPhone"
                name="shipperPhone"
                placeholder="+62-21-xxxx-xxxx"
                value={data.shipperPhone}
                onChange={handleChange}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="consignee">Nama Penerima</Label>
              <Input
                id="consignee"
                name="consignee"
                placeholder="ABC Trading Company"
                value={data.consignee}
                onChange={handleChange}
              />
            </div>
          </div>
        </div>

        {/* Shipment Details */}
        <div className="space-y-4">
          <h3 className="font-semibold">Detail Pengiriman</h3>
          <div className="grid md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="destination">Tujuan Pengiriman</Label>
              <Input
                id="destination"
                name="destination"
                placeholder="Singapore, Malaysia, Thailand"
                value={data.destination}
                onChange={handleChange}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="goodsType">Jenis Barang</Label>
              <Input
                id="goodsType"
                name="goodsType"
                placeholder="Elektronik, Tekstil, Minyak Sawit, dll"
                value={data.goodsType}
                onChange={handleChange}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="quantity">Jumlah (Unit)</Label>
              <Input
                id="quantity"
                name="quantity"
                type="number"
                placeholder="100"
                value={data.quantity}
                onChange={handleChange}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="weight">Berat (Ton)</Label>
              <Input
                id="weight"
                name="weight"
                type="number"
                placeholder="50"
                value={data.weight}
                onChange={handleChange}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="containerType">Tipe Kontainer</Label>
              <Input
                id="containerType"
                name="containerType"
                placeholder="20ft, 40ft, atau FCL/LCL"
                value={data.containerType}
                onChange={handleChange}
              />
            </div>
          </div>
        </div>

        {/* Services Selection */}
        <div className="space-y-4">
          <h3 className="font-semibold">Layanan Tambahan</h3>
          <div className="grid md:grid-cols-2 gap-4">
            {services.map((service) => (
              <label
                key={service.id}
                className="flex items-center gap-3 p-3 border border-border rounded-lg hover:bg-muted/50 cursor-pointer transition-colors"
              >
                <Checkbox
                  checked={data.services.includes(service.id)}
                  onCheckedChange={() => handleServiceToggle(service.id)}
                />
                <span className="text-sm">{service.label}</span>
              </label>
            ))}
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex justify-end gap-3 pt-4">
          <Button variant="outline">Batal</Button>
          <Button onClick={onNext} className="gap-2">
            Lanjut ke Validasi <ArrowRight className="w-4 h-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}
