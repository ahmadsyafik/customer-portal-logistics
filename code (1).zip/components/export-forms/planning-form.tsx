"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Check, Calendar, Truck } from "lucide-react"
import { useState } from "react"
import Link from "next/link"

interface PlanningFormProps {
  data: any
  onUpdate: (data: any) => void
  onBack: () => void
}

export function ExportPlanningForm({ data, onUpdate, onBack }: PlanningFormProps) {
  const [isSubmitted, setIsSubmitted] = useState(false)

  const vesselOptions = [
    { name: "Maersk Seatrade", eta: "2025-01-15", capacity: "2000 TEU" },
    { name: "MSC Gulsun", eta: "2025-01-18", capacity: "3000 TEU" },
    { name: "Ever Given", eta: "2025-01-20", capacity: "1800 TEU" },
  ]

  const truckTimeOptions = [
    { time: "08:00 - 10:00", slots: 5 },
    { time: "10:00 - 12:00", slots: 3 },
    { time: "14:00 - 16:00", slots: 8 },
  ]

  const handleVesselSelect = (vesselName: string, eta: string) => {
    onUpdate({ vesselName, eta })
  }

  const handleTruckTimeSelect = (time: string) => {
    onUpdate({ truckBookingTime: time })
  }

  const handleSubmit = () => {
    setIsSubmitted(true)
  }

  if (isSubmitted) {
    return (
      <Card className="border-border/50">
        <CardHeader>
          <CardTitle className="text-2xl">Pengiriman Berhasil Didaftarkan</CardTitle>
          <CardDescription>Pesanan ekspor Anda telah diproses</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="bg-green-500/10 border border-green-500/20 rounded-lg p-6 space-y-4">
            <div className="flex items-center justify-center w-12 h-12 mx-auto bg-green-500/20 rounded-full">
              <Check className="w-6 h-6 text-green-600" />
            </div>
            <div className="text-center space-y-2">
              <p className="font-semibold">Nomor Pesanan</p>
              <p className="text-2xl font-bold text-accent">SHP-2025-001234</p>
            </div>
          </div>

          <div className="space-y-4 bg-muted/30 rounded-lg p-4">
            <div className="flex items-center justify-between py-2">
              <span className="text-sm text-muted-foreground">Kapal</span>
              <span className="font-semibold">{data.vesselName}</span>
            </div>
            <div className="flex items-center justify-between py-2">
              <span className="text-sm text-muted-foreground">ETA</span>
              <span className="font-semibold">{data.eta}</span>
            </div>
            <div className="flex items-center justify-between py-2">
              <span className="text-sm text-muted-foreground">Waktu Truck Booking</span>
              <span className="font-semibold">{data.truckBookingTime}</span>
            </div>
            <div className="flex items-center justify-between py-2">
              <span className="text-sm text-muted-foreground">Tujuan</span>
              <span className="font-semibold">{data.destination}</span>
            </div>
          </div>

          <div className="bg-blue-500/10 border border-blue-500/20 rounded-lg p-4">
            <p className="text-sm text-muted-foreground">
              <strong>Langkah Berikutnya:</strong> Anda akan menerima email konfirmasi dan dapat memantau progres
              pengiriman di dashboard monitoring.
            </p>
          </div>

          <div className="flex gap-3 justify-end pt-4">
            <Link href="/dashboard">
              <Button variant="outline">Kembali ke Dashboard</Button>
            </Link>
            <Link href="/dashboard/tracking/SHP-2025-001234">
              <Button className="gap-2">
                <Calendar className="w-4 h-4" />
                Lihat Detail Pengiriman
              </Button>
            </Link>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card className="border-border/50">
      <CardHeader>
        <CardTitle className="text-2xl">Langkah 3: Perencanaan & Penjadwalan</CardTitle>
        <CardDescription>Pilih kapal dan waktu truck booking yang optimal</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* AI Recommendation */}
        <div className="bg-accent/5 border border-accent/20 rounded-lg p-4">
          <p className="text-sm">
            <strong>Rekomendasi AI:</strong> Berdasarkan data kepadatan pelabuhan dan kondisi cuaca, kapal{" "}
            <span className="text-accent font-semibold">Maersk Seatrade</span> dengan waktu truck booking{" "}
            <span className="text-accent font-semibold">14:00 - 16:00</span> adalah pilihan paling optimal untuk
            meminimalkan waktu tunggu.
          </p>
        </div>

        {/* Vessel Selection */}
        <div className="space-y-4">
          <h3 className="font-semibold">Pilih Kapal (Vessel)</h3>
          <div className="space-y-3">
            {vesselOptions.map((vessel) => (
              <button
                key={vessel.name}
                onClick={() => handleVesselSelect(vessel.name, vessel.eta)}
                className={`w-full text-left p-4 border rounded-lg transition-all ${
                  data.vesselName === vessel.name ? "border-accent bg-accent/5" : "border-border hover:border-accent/50"
                }`}
              >
                <div className="flex items-start justify-between">
                  <div>
                    <p className="font-semibold">{vessel.name}</p>
                    <p className="text-sm text-muted-foreground">Kapasitas: {vessel.capacity}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm text-muted-foreground">ETA</p>
                    <p className="font-semibold">{vessel.eta}</p>
                  </div>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Truck Booking Time */}
        <div className="space-y-4">
          <h3 className="font-semibold">Pilih Waktu Truck Booking</h3>
          <div className="space-y-3">
            {truckTimeOptions.map((option) => (
              <button
                key={option.time}
                onClick={() => handleTruckTimeSelect(option.time)}
                className={`w-full text-left p-4 border rounded-lg transition-all flex items-center justify-between ${
                  data.truckBookingTime === option.time
                    ? "border-secondary bg-secondary/5"
                    : "border-border hover:border-secondary/50"
                }`}
              >
                <div className="flex items-center gap-3">
                  <Truck className="w-5 h-5 text-secondary" />
                  <div>
                    <p className="font-semibold">{option.time}</p>
                    <p className="text-sm text-muted-foreground">{option.slots} slot tersedia</p>
                  </div>
                </div>
                {data.truckBookingTime === option.time && <Check className="w-5 h-5 text-secondary" />}
              </button>
            ))}
          </div>
        </div>

        {/* Summary */}
        <div className="space-y-4 bg-muted/30 rounded-lg p-4">
          <h3 className="font-semibold text-sm">Ringkasan Jadwal</h3>
          {data.vesselName && (
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Kapal Pilihan</span>
                <span className="font-semibold">{data.vesselName}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">ETA Kedatangan</span>
                <span className="font-semibold">{data.eta}</span>
              </div>
              {data.truckBookingTime && (
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Truck Booking</span>
                  <span className="font-semibold">{data.truckBookingTime}</span>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Action Buttons */}
        <div className="flex justify-between pt-4">
          <Button variant="outline" onClick={onBack}>
            Kembali
          </Button>
          <Button onClick={handleSubmit} disabled={!data.vesselName || !data.truckBookingTime} className="gap-2">
            <Check className="w-4 h-4" />
            Selesaikan Pemesanan
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}
